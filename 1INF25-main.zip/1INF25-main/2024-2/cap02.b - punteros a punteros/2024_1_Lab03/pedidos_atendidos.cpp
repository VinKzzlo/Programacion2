#include "pedidos_atendidos.hpp"
#include "libro.hpp"
#include "pedidos_libros.hpp"

void inicializar_pedidos_atendidos(bool **&pedidosAtendidos, int &capacidad_pedidos_atendidos) {
    
}

void atender_pedido(bool **&pedidosAtendidos, int &capacidad_pedidos_atendidos, int pedido_buffer, char***libros, int **stock, char ***pedidosLibros) {
    
}

bool atender_libro(char *codigo_libro, char ***libros, int **stock) {
    
}

void incrementar_espacio_pedidos_atendidos(bool **&pedidosAtendidos, int &capacidad_pedidos_atendidos, int pedido_buffer) {
    
}