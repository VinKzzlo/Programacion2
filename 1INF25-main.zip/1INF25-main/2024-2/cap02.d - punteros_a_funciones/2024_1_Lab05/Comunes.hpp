/* 
 * Archivo: Comunes.hpp
 * Autor: Andrés Melgar
 * Fecha: 7 de septiembre de 2024, 12:29
 */

#ifndef COMUNES_HPP
#define COMUNES_HPP

char *mi_strdup(char *cadena);

int *retorna_referencia_a_entero(int entero);

#endif /* COMUNES_HPP */

