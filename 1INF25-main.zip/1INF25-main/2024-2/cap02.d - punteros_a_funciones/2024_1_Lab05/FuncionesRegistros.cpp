#include <iostream>
#include <fstream>
#include "FuncionesRegistros.hpp"
#include "Comunes.hpp"

using namespace std;

void *leeregistro(ifstream &archivo_de_registro) {

}

void imprimeregistro(ofstream &archivo_de_registro, void *ptrRegistro) {

}

bool cmpregistro(void *ptrRegistroA, void *ptrRegistroB) {

}