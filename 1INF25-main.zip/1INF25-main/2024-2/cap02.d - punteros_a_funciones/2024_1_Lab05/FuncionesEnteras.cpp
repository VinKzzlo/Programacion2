#include <iostream>
#include <fstream>
#include "FuncionesEnteras.hpp"
#include "Comunes.hpp"

using namespace std;

void * leenum(ifstream &archivo_de_enteros) {

}

void imprimenum(ofstream &archivo_de_enteros, void *ptrEntero) {

}

bool cmpnum(void *ptrEnteroA, void *ptrEnteroB) {

}