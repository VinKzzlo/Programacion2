#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H

void cargaclientes(void *&clientes);
void creareserva(void *&reserva);
void cargareservar(void *clientes, void *reserva);

#endif /* PUNTEROSGENERICOS_H */

