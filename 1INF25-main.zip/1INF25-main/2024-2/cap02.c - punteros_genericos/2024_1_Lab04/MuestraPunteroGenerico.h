/* 
 * File:   MuestraPunteroGenerico.h
 * Author: cueva
 *
 * Created on 22 de abril de 2024, 05:27 PM
 */

#ifndef MUESTRAPUNTEROGENERICO_H
#define MUESTRAPUNTEROGENERICO_H

void muestraclientes(void *);
void muestrareservas(void *);
void reportefinal(void *);

#endif /* MUESTRAPUNTEROGENERICO_H */
