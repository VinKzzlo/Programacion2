#ifndef LIBRO_SOLICITADO_HPP
#define LIBRO_SOLICITADO_HPP

#include "Estructuras.h"

bool operator>>(LibroSolicitado &libroSolicitado, Libro arregloLibro[]);


#endif /* LIBRO_SOLICITADO_HPP */

