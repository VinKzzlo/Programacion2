/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bibliotecasComunes.hpp
 * Author: Usuario
 *
 * Created on 22 de mayo de 2024, 02:29 PM
 */

#ifndef BIBLIOTECASCOMUNES_HPP
#define BIBLIOTECASCOMUNES_HPP

#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

char *leeCadena(ifstream &arch,char delimitador);

#endif /* BIBLIOTECASCOMUNES_HPP */

