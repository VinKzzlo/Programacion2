/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MuestraPunteroGenerico.h
 * Author: cueva
 *
 * Created on 22 de abril de 2024, 05:27 PM
 */

#ifndef MUESTRAPUNTEROGENERICO_H
#define MUESTRAPUNTEROGENERICO_H
    void muestraclientes(void *);
    void muestrareservas(void *);
    void reportefinal(void *);
#endif /* MUESTRAPUNTEROGENERICO_H */
