
/* 
 * File:   main.cpp
 * Autor: Sebastian Grajeda
 * Codigo: 20210800
 * Created on 27 de abril de 2024, 02:24 PM
 */
#include "TesteoListas.h"
/*
 * 
 */
int main(int argc, char** argv) {
//    ListasV1();
//    ListasV2();
//    ListasV3();
    ListasV4();
    return 0;
}

