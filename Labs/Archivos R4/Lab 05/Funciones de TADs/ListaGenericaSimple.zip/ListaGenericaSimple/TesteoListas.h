/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TesteoListas.h
 * Author: ISA
 *
 * Created on 28 de abril de 2024, 01:23 PM
 */

#ifndef TESTEOLISTAS_H
#define TESTEOLISTAS_H

void ListasV1();
void ListasV2();
void ListasV3();
void ListasV4();

#endif /* TESTEOLISTAS_H */
