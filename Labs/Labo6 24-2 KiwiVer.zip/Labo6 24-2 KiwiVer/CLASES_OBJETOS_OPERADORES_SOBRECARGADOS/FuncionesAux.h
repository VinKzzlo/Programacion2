/* 
 * Archivo:   FuncionesAux.h
 * Autor:     VinKzzlo
 *
 * Creado el  7 de noviembre de 2024, 21:35
 */

#ifndef FUNCIONESAUX_H
#define FUNCIONESAUX_H

char *leeCadenaExacta(ifstream &arch, int max, char delim='\n');
void imprimeLinea(ofstream &arch,int cant, char car);
#endif /* FUNCIONESAUX_H */

