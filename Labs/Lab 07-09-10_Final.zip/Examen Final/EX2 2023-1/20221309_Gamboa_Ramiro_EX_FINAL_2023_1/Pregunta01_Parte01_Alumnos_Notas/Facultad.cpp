/* 
 * File:   Facultad.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:28 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Facultad.h"

Facultad::Facultad() {
}

Facultad::Facultad(const Facultad& orig) {
}

Facultad::~Facultad() {
}

void Facultad::leerAlumnosNotas(const char *nombArchAlum,
                                const char *nombArchNot){
    ifstream archAlum(nombArchAlum,ios::in);
    if(not archAlum.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchAlum<<endl;
        exit(1);
    }
    ifstream archNot(nombArchNot,ios::in);
    if(not archNot.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchNot<<endl;
        exit(1);
    }
    leerAlumnos(archAlum);
    leerNotas(archNot);
}

void Facultad::leerAlumnos(ifstream &archAlum){
    alumnosxNotas.creaLista(archAlum);
}

void Facultad::leerNotas(ifstream &archNot){
    alumnosxNotas.cargaNotas(archNot);
}

void Facultad::imprimeAlumnosNotas(const char *nombArch){
    
}