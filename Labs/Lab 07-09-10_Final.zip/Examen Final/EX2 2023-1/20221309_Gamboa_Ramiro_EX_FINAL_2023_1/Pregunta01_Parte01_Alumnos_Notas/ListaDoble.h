/* 
 * File:   ListaDoble.h
 * Author: ramir
 *
 * Created on 23 de junio de 2024, 12:28 AM
 */

#ifndef LISTADOBLE_H
#define LISTADOBLE_H

#include "Nodo.h"

class ListaDoble {
public:
    ListaDoble();
    ListaDoble(const ListaDoble& orig);
    virtual ~ListaDoble();
    void creaLista(ifstream &);
    void cargaNotas(ifstream &);
private:
    Nodo *inicio;
    Nodo *fin;
    void insertar(class Nodo*);
    void agregarNota(int,class Nota&);
};

#endif /* LISTADOBLE_H */

