/* 
 * File:   AlumnoNotas.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:25 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "AlumnoNotas.h"

AlumnoNotas::AlumnoNotas() {
}

AlumnoNotas::AlumnoNotas(const AlumnoNotas& orig) {
}

AlumnoNotas::~AlumnoNotas() {
}

bool AlumnoNotas::leerDatos(ifstream &archAlum){
    archAlum>>alumno;
    if(archAlum.eof()) return false;
    return true;
}

int AlumnoNotas::GetCodigo_alumno() const{
    return alumno.GetCodigo_alumno();
}

void AlumnoNotas::agregaNotaAlumno(class Nota &nota){
    int cantAnt = notas.size();
    notas.push_back(nota);
    int cantFinal = notas.size();
    alumno.SetPromedio((alumno.GetPromedio()*cantAnt+nota.GetCalificacion())
                        /cantFinal);
}