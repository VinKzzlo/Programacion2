/* 
 * File:   Alumno.h
 * Author: ramir
 *
 * Created on 23 de junio de 2024, 12:24 AM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void SetPromedio(double promedio);
    double GetPromedio() const;
    void SetCodigo_alumno(int codigo_alumno);
    int GetCodigo_alumno() const;
    void SetNombre(char *cad);
    void GetNombre(char *cad) const;
    void imprimeAlumno(ofstream &);
private:
    int codigo_alumno;
    char *nombre;
    double promedio;
};
ifstream &operator >> (ifstream &archAlum,class Alumno &alum);

#endif /* ALUMNO_H */

