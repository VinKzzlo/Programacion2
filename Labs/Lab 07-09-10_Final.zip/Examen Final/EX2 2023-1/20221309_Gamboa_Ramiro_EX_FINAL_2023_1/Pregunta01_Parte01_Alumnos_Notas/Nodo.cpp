/* 
 * File:   Nodo.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:26 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    siguiente = nullptr;
    anterior = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}