/* 
 * File:   Nota.h
 * Author: ramir
 *
 * Created on 23 de junio de 2024, 12:22 AM
 */

#ifndef NOTA_H
#define NOTA_H

class Nota {
public:
    Nota();
    Nota(const Nota& orig);
    void operator = (const Nota&);
    virtual ~Nota();
    void SetVez(int vez);
    int GetVez() const;
    void SetCalificacion(int calificacion);
    int GetCalificacion() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodigo_curso(char *cad);
    void GetCodigo_curso(char *cad) const;
private:
    int ciclo;
    char *codigo_curso;
    double creditos;
    int calificacion;
    int vez;
};
ifstream &operator >> (ifstream &archAlum,class Nota &nota);

#endif /* NOTA_H */

