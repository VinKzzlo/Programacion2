/* 
 * File:   AlumnoNotas.h
 * Author: ramir
 *
 * Created on 23 de junio de 2024, 12:25 AM
 */

#ifndef ALUMNONOTAS_H
#define ALUMNONOTAS_H

#include <vector>

#include "Alumno.h"
#include "Nota.h"

class AlumnoNotas {
public:
    AlumnoNotas();
    AlumnoNotas(const AlumnoNotas& orig);
    virtual ~AlumnoNotas();
    bool leerDatos(ifstream &);
    int GetCodigo_alumno() const;
    void agregaNotaAlumno(class Nota &);
private:
    Alumno alumno;
    vector<class Nota>notas;
};

#endif /* ALUMNONOTAS_H */

