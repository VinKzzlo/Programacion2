/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 23 de junio de 2024, 12:20 AM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Facultad.h"
int main(int argc, char** argv) {
    
    class Facultad facultad;
    
    facultad.leerAlumnosNotas("Alumnos-Preg01.csv","Notas-Preg01.csv");
    facultad.imprimeAlumnosNotas("PruebaAlumnosNotas.txt");
    
    return 0;
}

