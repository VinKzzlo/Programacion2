/* 
 * File:   ListaDoble.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:28 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "ListaDoble.h"

ListaDoble::ListaDoble() {
    inicio = nullptr;
    fin = nullptr;
}

ListaDoble::ListaDoble(const ListaDoble& orig) {
}

ListaDoble::~ListaDoble() {
}
/*
202111260,GORDILLO CASTRO RONAL
202111397,ZEVALLOS PRADO RICARDO
*/
void ListaDoble::creaLista(ifstream &archAlum){
    Nodo *nuevo = new Nodo;
    while(nuevo->dato.leerDatos(archAlum)){
        insertar(nuevo);
        nuevo = new Nodo;
    }
}

void ListaDoble::insertar(class Nodo *nuevo){
    Nodo *p = inicio,*ant = nullptr;
    if(inicio==nullptr){
        inicio = nuevo;
        fin = nuevo;
    }else{
        while(p){
            if(p->dato.GetCodigo_alumno()>nuevo->dato.GetCodigo_alumno()) break;
            ant = p;
            p = p->siguiente;
        }
        nuevo->siguiente = p;
        nuevo->anterior = ant;
        
        if(p) p->anterior = nuevo;
        else fin = nuevo;
        
        if(ant) ant->siguiente = nuevo;
        else inicio = nuevo;
    }
}
/*
20201,202115400,INF281,5,5,MEC206,4.5,15,FIS208,4.5,5
20201,202121791,INF246,3.75,15
*/
void ListaDoble::cargaNotas(ifstream &archNot){
    int ciclo,codAlum;
    char c;
    class Nota nota;
    while(1){
        archNot>>ciclo;
        if(archNot.eof()) break;
        archNot>>c>>codAlum>>c;
        nota.SetCiclo(ciclo);
        while(1){
            archNot>>nota;
            agregarNota(codAlum,nota);
            if(archNot.get()=='\n') break;
        }
    }
}

void ListaDoble::agregarNota(int codAlum,class Nota &nota){
    Nodo *p = inicio;
    while(p){
        if(p->dato.GetCodigo_alumno()==codAlum){
            p->dato.agregaNotaAlumno(nota);
            break;
        }
        p = p->siguiente;
    }
}