/* 
 * File:   Facultad.h
 * Author: ramir
 *
 * Created on 23 de junio de 2024, 12:28 AM
 */

#ifndef FACULTAD_H
#define FACULTAD_H

#include "ListaDoble.h"

class Facultad {
public:
    Facultad();
    Facultad(const Facultad& orig);
    virtual ~Facultad();
    void leerAlumnosNotas(const char*,const char*);
    void imprimeAlumnosNotas(const char*);
private:
    ListaDoble alumnosxNotas;
    void leerAlumnos(ifstream &);
    void leerNotas(ifstream &);
};

#endif /* FACULTAD_H */

