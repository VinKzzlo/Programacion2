/* 
 * File:   Alumno.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:24 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Alumno.h"

Alumno::Alumno() {
    codigo_alumno = 0;
    nombre = nullptr;
    promedio = 0.0;
}

Alumno::Alumno(const Alumno& orig) {
}

Alumno::~Alumno() {
}

void Alumno::SetPromedio(double promedio) {
    this->promedio = promedio;
}

double Alumno::GetPromedio() const {
    return promedio;
}

void Alumno::SetCodigo_alumno(int codigo_alumno) {
    this->codigo_alumno = codigo_alumno;
}

int Alumno::GetCodigo_alumno() const {
    return codigo_alumno;
}

void Alumno::SetNombre(char *cad){
    if(nombre) delete nombre;
    nombre = new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
    
void Alumno::GetNombre(char *cad) const{
    if(nombre) strcpy(cad,nombre);
    else cad[0] = '\0';
}

//bool Alumno::operator >> (ifstream &archAlum){
//    char nomb[60];
//    
//    archAlum>>codigo_alumno;
//    if(archAlum.eof()) return false;
//    archAlum.get();
//    archAlum.getline(nomb,60);
//    SetNombre(nomb);
//    return true;
//}
/*
202111260,GORDILLO CASTRO RONAL
202111397,ZEVALLOS PRADO RICARDO
*/
ifstream &operator >> (ifstream &archAlum,class Alumno &alum){
    int codigo;
    char nomb[60];
    
    archAlum>>codigo;
    if(!archAlum.eof()){
        archAlum.get();
        archAlum.getline(nomb,60);
        alum.SetCodigo_alumno(codigo);
        alum.SetNombre(nomb);
    }
    return archAlum;
}

void Alumno::imprimeAlumno(ofstream &archRep){
    archRep<<left<<setw(15)<<codigo_alumno<<setw(60)<<nombre<<endl;
}