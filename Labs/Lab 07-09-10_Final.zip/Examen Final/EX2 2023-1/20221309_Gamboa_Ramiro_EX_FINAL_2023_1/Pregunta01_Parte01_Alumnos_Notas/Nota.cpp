/* 
 * File:   Nota.cpp
 * Author: ramir
 * 
 * Created on 23 de junio de 2024, 12:22 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nota.h"

Nota::Nota() {
    ciclo = 0;
    codigo_curso = nullptr;
    creditos = 0.0;
    calificacion = 0;
    vez = 0;
}

Nota::Nota(const Nota& orig) {
    (*this) = orig;
}

void Nota::operator = (const Nota& orig){
    calificacion = orig.calificacion;
    ciclo = orig.ciclo;
    vez = orig.vez;
    creditos = orig.creditos;
    codigo_curso = nullptr;
    SetCodigo_curso(orig.codigo_curso);
}

Nota::~Nota() {
}

void Nota::SetVez(int vez) {
    this->vez = vez;
}

int Nota::GetVez() const {
    return vez;
}

void Nota::SetCalificacion(int calificacion) {
    this->calificacion = calificacion;
}

int Nota::GetCalificacion() const {
    return calificacion;
}

void Nota::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double Nota::GetCreditos() const {
    return creditos;
}

void Nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int Nota::GetCiclo() const {
    return ciclo;
}

void Nota::SetCodigo_curso(char *cad){
    if(codigo_curso) delete codigo_curso;
    codigo_curso = new char[strlen(cad)+1];
    strcpy(codigo_curso,cad);
}
    
void Nota::GetCodigo_curso(char *cad) const{
    if(codigo_curso) strcpy(cad,codigo_curso);
    else cad[0] = '\0';
}
//MAT218,4.5,13
ifstream &operator >> (ifstream &archAlum,class Nota &nota){
    int calificacion;
    double creditos;
    char codCurso[7],c;
    
    archAlum.getline(codCurso,7,',');
    archAlum>>creditos>>c>>calificacion;
    nota.SetCodigo_curso(codCurso);
    nota.SetCreditos(creditos);
    nota.SetCalificacion(calificacion);
    return archAlum;
}