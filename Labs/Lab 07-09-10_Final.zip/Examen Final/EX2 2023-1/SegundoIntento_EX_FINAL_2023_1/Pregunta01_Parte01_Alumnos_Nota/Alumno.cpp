/* 
 * File:   Alumno.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:13 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Alumno.h"

Alumno::Alumno() {
    codigo_alumno = 0;
    nombre = nullptr;
    promedio = 0.0;
}

Alumno::Alumno(const Alumno& orig) {
    *this = orig;
}

void Alumno::operator = (const class Alumno &aux){
    char nomb[60];
    
    aux.GetNombre(nomb);
    this->SetNombre(nomb);
    this->codigo_alumno = aux.codigo_alumno;
    this->promedio = aux.promedio;
}

Alumno::~Alumno() {
}

void Alumno::SetPromedio(double promedio) {
    this->promedio = promedio;
}

double Alumno::GetPromedio() const {
    return promedio;
}

void Alumno::SetCodigo_alumno(int codigo_alumno) {
    this->codigo_alumno = codigo_alumno;
}

int Alumno::GetCodigo_alumno() const {
    return codigo_alumno;
}

void Alumno::SetNombre(char *cad){
    if(nombre) delete nombre;
    nombre = new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
    
void Alumno::GetNombre(char *cad) const{
    if(nombre) strcpy(cad,nombre);
    else cad[0] = '\0';
}
//202111260,GORDILLO CASTRO RONAL
ifstream &operator >> (ifstream &archAlum,class Alumno &alum){
    int codigo;
    char nomb[60];
    
    archAlum>>codigo;
    if(!archAlum.eof()){
        archAlum.get();
        archAlum.getline(nomb,60);
        alum.SetCodigo_alumno(codigo);
        alum.SetNombre(nomb);
    }
    return archAlum;
}

void Alumno::imprimirAlumno(ofstream &archRep){
    archRep<<"Codigo: "<<codigo_alumno<<endl;
    archRep<<"Alumno: "<<nombre<<endl;
    archRep<<"Promedio: "<<promedio<<endl;
}