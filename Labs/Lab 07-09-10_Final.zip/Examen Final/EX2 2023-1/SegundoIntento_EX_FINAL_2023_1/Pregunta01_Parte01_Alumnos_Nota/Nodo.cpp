/* 
 * File:   Nodo.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:15 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    siguiente = nullptr;
    anterior = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

