/* 
 * File:   Nodo.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:15 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Nodo.h"
#include "AlumnoNotas.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class ListaDoble;
private:
    AlumnoNotas dato;
    Nodo *siguiente;
    Nodo *anterior;
};

#endif /* NODO_H */

