/* 
 * File:   Nota.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:08 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nota.h"

Nota::Nota() {
    ciclo = 0;
    codigo_curso = nullptr;
    creditos = 0.0;
    calificacion = 0;
    vez = 1;
}

Nota::Nota(const Nota& orig) {
    this->codigo_curso = nullptr;
    *this = orig;
}

void Nota::operator = (const class Nota &aux){
    this->SetCodigo_Curso(aux.codigo_curso);
    this->ciclo = aux.ciclo;
    this->creditos = aux.creditos;
    this->calificacion = aux.calificacion;
    this->vez = aux.vez;
}

Nota::~Nota() {
}

void Nota::SetVez(int vez) {
    this->vez = vez;
}

int Nota::GetVez() const {
    return vez;
}

void Nota::SetCalificacion(int calificacion) {
    this->calificacion = calificacion;
}

int Nota::GetCalificacion() const {
    return calificacion;
}

void Nota::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double Nota::GetCreditos() const {
    return creditos;
}

void Nota::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int Nota::GetCiclo() const {
    return ciclo;
}

void Nota::SetCodigo_Curso(char *cad){
    if(codigo_curso) delete codigo_curso;
    codigo_curso = new char[strlen(cad)+1];
    strcpy(codigo_curso,cad);
}
    
void Nota::GetCodigo_Curso(char *cad) const{
    if(codigo_curso) strcpy(cad,codigo_curso);
    else cad[0] = '\0';
}
//INF246,3.75,15
ifstream &operator >> (ifstream &archNot,class Nota &nota){
    int calificacion;
    double creditos;
    char codCurso[7],c;
    
    archNot.getline(codCurso,7,',');
    archNot>>creditos>>c>>calificacion;
    nota.SetCodigo_Curso(codCurso);
    nota.SetCreditos(creditos);
    nota.SetCalificacion(calificacion);
    return archNot;
}

void Nota::imprimirNota(ofstream &archRep){
    archRep<<left<<setw(6)<<ciclo<<setw(12)<<codigo_curso<<setw(14)<<creditos
           <<setw(10)<<calificacion<<setw(14)<<vez<<endl;
}