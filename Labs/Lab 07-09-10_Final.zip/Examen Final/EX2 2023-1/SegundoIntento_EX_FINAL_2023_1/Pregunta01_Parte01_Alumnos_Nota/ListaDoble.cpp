/* 
 * File:   ListaDoble.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:15 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "ListaDoble.h"
#define MAX_LINEA 60
ListaDoble::ListaDoble() {
    inicio = nullptr;
    fin = nullptr;
}

ListaDoble::ListaDoble(const ListaDoble& orig) {
}

ListaDoble::~ListaDoble() {
}
/*
202111260,GORDILLO CASTRO RONAL
202111397,ZEVALLOS PRADO RICARDO
*/
void ListaDoble::creaLista(ifstream &archAlum){
    Alumno alum;
    while(archAlum>>alum){
        if(!seRepiteAlumno(alum.GetCodigo_alumno())){
            insertarAlumno(alum);
        }
    }
}

bool ListaDoble::seRepiteAlumno(int codigo){
    Nodo *p = inicio;
    while(p){
        if(p->dato.GetCodigo_Alumno()==codigo) return true;
        p = p->siguiente;
    }
    return false;
}

void ListaDoble::insertarAlumno(class Alumno &alum){
    Nodo *p = inicio, *nuevo = new Nodo, *ant = nullptr;
    nuevo->dato.agregarAlumno(alum);
    if(inicio==nullptr){
        inicio = nuevo;
        fin = nuevo;
    }else{
        while(p){
            if(p->dato.GetCodigo_Alumno() > nuevo->dato.GetCodigo_Alumno())
                break;
            ant = p;
            p = p->siguiente;
        }
        nuevo->anterior = ant;
        nuevo->siguiente = p;
        
        if(ant) ant->siguiente = nuevo;
        else inicio = nuevo;
        
        if(p) p->anterior = nuevo;
        else fin = nuevo;
    }
}
/*
20201,202115400,INF281,5,5,MEC206,4.5,15,FIS208,4.5,5
20201,202121791,INF246,3.75,15
*/
void ListaDoble::llenaNotas(ifstream &archNot){
    int ciclo,codAlum;
    char c;
    Nota nota;
    while(1){
        archNot>>ciclo;
        if(archNot.eof()) break;
        archNot>>c>>codAlum>>c;
        nota.SetCiclo(ciclo);
        while(1){
            archNot>>nota;
            agregarNotasAlumno(codAlum,nota);
            if(archNot.get()=='\n') break;
        }
    }
}

void ListaDoble::agregarNotasAlumno(int codAlum,class Nota &nota){
    Nodo *p = inicio;
    while(p){
        if(p->dato.GetCodigo_Alumno()==codAlum){
            p->dato.agregarNota(nota);
            break;
        }
        p = p->siguiente;
    }
}

void ListaDoble::imprimeLista(ofstream &archRep){
    archRep<<right<<setw(37)<<"REPORTE DE FACULTAD"<<endl;
    imprimirLinea(archRep,'=');
    archRep<<fixed<<setprecision(2);
    Nodo *p = inicio;
    while(p){
        p->dato.imprimirAlumnoNotas(archRep);
        p = p->siguiente;
    }
}

void ListaDoble::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}