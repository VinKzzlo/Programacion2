/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 8 de julio de 2024, 09:07 AM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Facultad.h"
int main(int argc, char** argv) {
    
    Facultad facultad;
    
    facultad.leerAlumnosNotas("Alumnos-Preg01.csv","Notas-Preg01.csv");
    facultad.imprimeAlumnosNotas("PruebaAlumnosNotas.txt");
    
    return 0;
}

