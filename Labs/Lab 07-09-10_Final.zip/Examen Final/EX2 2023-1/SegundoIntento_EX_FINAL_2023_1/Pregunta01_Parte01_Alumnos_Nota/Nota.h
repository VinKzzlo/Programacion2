/* 
 * File:   Nota.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:08 AM
 */

#ifndef NOTA_H
#define NOTA_H

class Nota {
public:
    Nota();
    Nota(const Nota& orig);
    virtual ~Nota();
    void operator = (const class Nota &);
    void SetVez(int vez);
    int GetVez() const;
    void SetCalificacion(int calificacion);
    int GetCalificacion() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodigo_Curso(char *cad);
    void GetCodigo_Curso(char *cad) const;
    void imprimirNota(ofstream &);
private:
    int ciclo;
    char *codigo_curso;
    double creditos;
    int calificacion;
    int vez;
};
ifstream &operator >> (ifstream &,class Nota &);

#endif /* NOTA_H */

