/* 
 * File:   Alumno.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:13 AM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

class Alumno {
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void operator = (const class Alumno &);
    void SetPromedio(double promedio);
    double GetPromedio() const;
    void SetCodigo_alumno(int codigo_alumno);
    int GetCodigo_alumno() const;
    void SetNombre(char *cad);
    void GetNombre(char *cad) const;
    void imprimirAlumno(ofstream &);
private:
    int codigo_alumno;
    char *nombre;
    double promedio;
};
ifstream &operator >> (ifstream &,class Alumno &);

#endif /* ALUMNO_H */

