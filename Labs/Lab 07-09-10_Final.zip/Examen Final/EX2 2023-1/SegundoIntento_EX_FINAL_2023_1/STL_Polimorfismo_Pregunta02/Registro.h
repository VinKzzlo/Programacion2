/* 
 * File:   Registro.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:40 PM
 */

#ifndef REGISTRO_H
#define REGISTRO_H

#include <vector>

#include "Nota.h"

class Registro {
public:
    Registro();
    Registro(const Registro& orig);
    virtual ~Registro();
    void carga();
    void procesa();
    void muestra();
private:
    vector<class Nota>vregistro;
};

#endif /* REGISTRO_H */

