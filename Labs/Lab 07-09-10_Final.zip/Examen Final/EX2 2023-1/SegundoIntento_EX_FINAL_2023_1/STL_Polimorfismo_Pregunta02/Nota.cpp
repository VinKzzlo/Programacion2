/* 
 * File:   Nota.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:40 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nota.h"

Nota::Nota() {
    pnota = nullptr;
}

Nota::Nota(const Nota& orig) {
    this->pnota = orig.pnota;
}

Nota::~Nota() {
}

