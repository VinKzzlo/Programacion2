/* 
 * File:   Segunda.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:38 PM
 */

#ifndef SEGUNDA_H
#define SEGUNDA_H

#include "CursoAlumno.h"

class Segunda:public CursoAlumno {
public:
    Segunda();
    Segunda(const Segunda& orig);
    virtual ~Segunda();
    void SetCreditos(double creditos);
    double GetCreditos() const;
private:
    double creditos;
};

#endif /* SEGUNDA_H */

