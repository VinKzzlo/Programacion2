/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 8 de julio de 2024, 11:34 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Registro.h"
int main(int argc, char** argv) {
    
    Registro reg;
    
    reg.carga();
    reg.procesa();
    reg.muestra();
    
    return 0;
}

