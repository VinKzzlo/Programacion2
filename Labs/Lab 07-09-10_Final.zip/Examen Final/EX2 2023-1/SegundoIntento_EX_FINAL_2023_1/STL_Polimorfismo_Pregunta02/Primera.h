/* 
 * File:   Primera.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:37 PM
 */

#ifndef PRIMERA_H
#define PRIMERA_H

#include "CursoAlumno.h"

class Primera:public CursoAlumno {
public:
    Primera();
    Primera(const Primera& orig);
    virtual ~Primera();
    void SetCodacceso(char *cad);
    void GetCodacceso(char *cad) const;
private:
    char *codacceso;
};

#endif /* PRIMERA_H */

