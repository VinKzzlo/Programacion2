/* 
 * File:   Segunda.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:38 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Segunda.h"

Segunda::Segunda() {
    creditos = 0.0;
}

Segunda::Segunda(const Segunda& orig) {
}

Segunda::~Segunda() {
}

void Segunda::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double Segunda::GetCreditos() const {
    return creditos;
}

