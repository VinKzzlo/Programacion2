/* 
 * File:   Nota.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:40 PM
 */

#ifndef NOTA_H
#define NOTA_H

#include "CursoAlumno.h"

class Nota {
public:
    Nota();
    Nota(const Nota& orig);
    virtual ~Nota();
private:
    CursoAlumno *pnota;
};

#endif /* NOTA_H */

