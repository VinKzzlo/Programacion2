/* 
 * File:   CursoAlumno.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:34 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "CursoAlumno.h"

CursoAlumno::CursoAlumno() {
    codigo = 0;
    codcur = nullptr;
    ciclo = 0;
    creditos = 0.0;
    nota = 0;
}

CursoAlumno::CursoAlumno(const CursoAlumno& orig) {
}

CursoAlumno::~CursoAlumno() {
}

void CursoAlumno::SetNota(int nota) {
    this->nota = nota;
}

int CursoAlumno::GetNota() const {
    return nota;
}

void CursoAlumno::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double CursoAlumno::GetCreditos() const {
    return creditos;
}

void CursoAlumno::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int CursoAlumno::GetCiclo() const {
    return ciclo;
}

void CursoAlumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int CursoAlumno::GetCodigo() const {
    return codigo;
}

void CursoAlumno::SetCodcur(char *cad){
    if(codcur) delete codcur;
    codcur = new char[strlen(cad)+1];
    strcpy(codcur,cad);
}
    
void CursoAlumno::GetCodcur(char *cad) const{
    if(codcur) strcpy(cad,codcur);
    else cad[0] = '\0';
}