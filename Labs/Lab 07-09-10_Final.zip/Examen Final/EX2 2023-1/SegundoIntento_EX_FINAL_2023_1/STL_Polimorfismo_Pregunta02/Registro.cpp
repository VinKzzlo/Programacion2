/* 
 * File:   Registro.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:40 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Registro.h"

Registro::Registro() {
}

Registro::Registro(const Registro& orig) {
}

Registro::~Registro() {
}

void Registro::carga(){
    ifstream archNot("registronotas.csv",ios::in);
    if(not archNot.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo registronotas.csv"<<endl;
        exit(1);
    }
}

void Registro::procesa(){
    
}

void Registro::muestra(){
    
}