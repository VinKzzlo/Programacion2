/* 
 * File:   CursoAlumno.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:34 PM
 */

#ifndef CURSOALUMNO_H
#define CURSOALUMNO_H

class CursoAlumno {
public:
    CursoAlumno();
    CursoAlumno(const CursoAlumno& orig);
    virtual ~CursoAlumno();
    void SetNota(int nota);
    int GetNota() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void SetCodcur(char *cad);
    void GetCodcur(char *cad) const;
private:
    int codigo;
    char *codcur;
    int ciclo;
    double creditos;
    int nota;
};

#endif /* CURSOALUMNO_H */

