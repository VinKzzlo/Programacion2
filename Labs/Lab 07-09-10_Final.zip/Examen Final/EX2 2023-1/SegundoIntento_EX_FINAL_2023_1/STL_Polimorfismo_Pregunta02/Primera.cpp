/* 
 * File:   Primera.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:37 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Primera.h"

Primera::Primera() {
    codacceso = nullptr;
}

Primera::Primera(const Primera& orig) {
}

Primera::~Primera() {
}

void Primera::SetCodacceso(char *cad){
    if(codacceso) delete codacceso;
    codacceso = new char[strlen(cad)+1];
    strcpy(codacceso,cad);
}
    
void Primera::GetCodacceso(char *cad) const{
    if(codacceso) strcpy(cad,codacceso);
    else cad[0] = '\0';
}