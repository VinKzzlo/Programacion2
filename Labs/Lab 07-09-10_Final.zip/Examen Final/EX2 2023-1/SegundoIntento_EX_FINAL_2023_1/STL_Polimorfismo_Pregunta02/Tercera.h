/* 
 * File:   Tercera.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 11:39 PM
 */

#ifndef TERCERA_H
#define TERCERA_H

#include "CursoAlumno.h"

class Tercera:public CursoAlumno {
public:
    Tercera();
    Tercera(const Tercera& orig);
    virtual ~Tercera();
    void SetPorcentaje(double porcentaje);
    double GetPorcentaje() const;
private:
    double porcentaje;
};

#endif /* TERCERA_H */

