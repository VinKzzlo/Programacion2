/* 
 * File:   Tercera.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 11:39 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Tercera.h"

Tercera::Tercera() {
    porcentaje = 0.0;
}

Tercera::Tercera(const Tercera& orig) {
}

Tercera::~Tercera() {
}

void Tercera::SetPorcentaje(double porcentaje) {
    this->porcentaje = porcentaje;
}

double Tercera::GetPorcentaje() const {
    return porcentaje;
}

