/* 
 * File:   Facultad.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:16 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Facultad.h"

Facultad::Facultad() {
}

Facultad::Facultad(const Facultad& orig) {
}

Facultad::~Facultad() {
}

void Facultad::leerAlumnosNotas(const char *nombArchAlum,const char *nombArchNot){
    leerAlumnos(nombArchAlum);
    leerNotas(nombArchNot);
}

void Facultad::leerAlumnos(const char *nombArch){
    ifstream archAlum(nombArch,ios::in);
    if(not archAlum.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    alumnosxNotas.creaLista(archAlum);
}

void Facultad::leerNotas(const char *nombArch){
    ifstream archNot(nombArch,ios::in);
    if(not archNot.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    alumnosxNotas.llenaNotas(archNot);
}

void Facultad::imprimeAlumnosNotas(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    alumnosxNotas.imprimeLista(archRep);
}

void Facultad::actualizaNotas(){
    alumnosxNotas.actualiza();
}