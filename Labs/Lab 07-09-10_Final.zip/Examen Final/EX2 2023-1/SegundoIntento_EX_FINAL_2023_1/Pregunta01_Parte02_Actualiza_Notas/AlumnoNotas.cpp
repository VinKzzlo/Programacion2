/* 
 * File:   AlumnoNotas.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 09:14 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <iterator>
using namespace std;
#include "AlumnoNotas.h"
#define MAX_LINEA 60
#define NO_ENCONTRADO -1
AlumnoNotas::AlumnoNotas() {
}

AlumnoNotas::AlumnoNotas(const AlumnoNotas& orig) {
}

AlumnoNotas::~AlumnoNotas() {
}

int AlumnoNotas::GetCodigo_Alumno() const{
    return alumno.GetCodigo_alumno();
}

void AlumnoNotas::agregarAlumno(class Alumno &alum){
    alumno = alum;
}

void AlumnoNotas::agregarNota(class Nota &nota){
    int cant=0,cantAnt=notas.size();
    char codCurso[7],codCursoEncontrado[7];
    nota.GetCodigo_Curso(codCurso);
    for(int i=0;i<notas.size();i++){
        notas[i].GetCodigo_Curso(codCursoEncontrado);
        if(strcmp(codCurso,codCursoEncontrado)==0) cant++;
    }
    nota.SetVez(cant+1);
    alumno.SetPromedio((alumno.GetPromedio()*cantAnt+nota.GetCalificacion())
                       /(cantAnt+1));
    notas.push_back(nota);
}

void AlumnoNotas::imprimirAlumnoNotas(ofstream &archRep){
    alumno.imprimirAlumno(archRep);
    archRep<<"Notas:"<<endl;
    archRep<<left<<setw(6)<<"Ciclo"<<setw(10)<<"Curso"<<setw(10)<<"Creditos"
           <<setw(15)<<"Calificacion"<<setw(10)<<"Vez"<<endl;
    imprimirLinea(archRep,'=');
    for(int i=0;i<notas.size();i++){
        notas[i].imprimirNota(archRep);
    }
    imprimirLinea(archRep,'=');
}

void AlumnoNotas::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}

void AlumnoNotas::actualizar(){
    int posNot;
    char codCurso[7];
    vector<class Nota>nuevasNotas;
    for(int i=0;i<notas.size();i++){
        notas[i].GetCodigo_Curso(codCurso);
        posNot = buscarNota(nuevasNotas,codCurso);
        if(posNot==NO_ENCONTRADO){
            nuevasNotas.push_back(notas[i]);
        }else{
            if(notas[i].GetCiclo()>nuevasNotas[posNot].GetCiclo()){
                nuevasNotas[posNot].SetCiclo(notas[i].GetCiclo());
                nuevasNotas[posNot].SetCalificacion(notas[i].GetCalificacion());
            }
            nuevasNotas[posNot].SetVez(nuevasNotas[posNot].GetVez()+1);
        }
    }
    notas = nuevasNotas;    //Actualizacion
}

int AlumnoNotas::buscarNota(vector<class Nota> &nuevasNotas,char *codCurso){
    char codCursoEncontrado[7];
    for(int i=0;i<nuevasNotas.size();i++){
        nuevasNotas[i].GetCodigo_Curso(codCursoEncontrado);
        if(strcmp(codCurso,codCursoEncontrado)==0) return i;
    }
    return NO_ENCONTRADO;
}

void AlumnoNotas::totalizar(){
    double sumaTotal=0;
    if(notas.size()>0){
        for(int i=0;i<notas.size();i++)
            sumaTotal += notas[i].GetCalificacion();
        alumno.SetPromedio(sumaTotal/notas.size());
    }else{
        alumno.SetPromedio(0);
    }
    
}