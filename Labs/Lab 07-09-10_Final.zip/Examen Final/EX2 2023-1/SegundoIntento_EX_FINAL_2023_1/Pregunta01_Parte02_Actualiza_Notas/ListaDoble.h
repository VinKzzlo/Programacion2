/* 
 * File:   ListaDoble.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:15 AM
 */

#ifndef LISTADOBLE_H
#define LISTADOBLE_H

#include "Nodo.h"

class ListaDoble {
public:
    ListaDoble();
    ListaDoble(const ListaDoble& orig);
    virtual ~ListaDoble();
    void creaLista(ifstream &);
    bool seRepiteAlumno(int);
    void llenaNotas(ifstream &);
    void imprimeLista(ofstream &);
    void actualiza();
private:
    Nodo *inicio;
    Nodo *fin;
    void insertarAlumno(class Alumno &);
    void agregarNotasAlumno(int,class Nota &);
    void imprimirLinea(ofstream &,char);
};

#endif /* LISTADOBLE_H */

