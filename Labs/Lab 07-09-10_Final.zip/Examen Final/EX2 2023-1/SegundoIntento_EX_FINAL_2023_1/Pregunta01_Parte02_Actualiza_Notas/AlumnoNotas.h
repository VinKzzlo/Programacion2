/* 
 * File:   AlumnoNotas.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:14 AM
 */

#ifndef ALUMNONOTAS_H
#define ALUMNONOTAS_H

#include <vector>

#include "Alumno.h"
#include "Nota.h"

class AlumnoNotas {
public:
    AlumnoNotas();
    AlumnoNotas(const AlumnoNotas& orig);
    virtual ~AlumnoNotas();
    void agregarAlumno(class Alumno &);
    int GetCodigo_Alumno() const;
    void agregarNota(class Nota &);
    void imprimirAlumnoNotas(ofstream &);
    void actualizar();
    void totalizar();
private:
    Alumno alumno;
    vector<class Nota>notas;
    void imprimirLinea(ofstream &,char);
    int buscarNota(vector<class Nota> &,char*);
};

#endif /* ALUMNONOTAS_H */

