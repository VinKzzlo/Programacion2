/* 
 * File:   Facultad.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 09:16 AM
 */

#ifndef FACULTAD_H
#define FACULTAD_H

#include "ListaDoble.h"

class Facultad {
public:
    Facultad();
    Facultad(const Facultad& orig);
    virtual ~Facultad();
    void leerAlumnosNotas(const char*,const char*);
    void imprimeAlumnosNotas(const char*);
    void actualizaNotas();
private:
    ListaDoble alumnosxNotas;
    void leerAlumnos(const char*);
    void leerNotas(const char*);
};

#endif /* FACULTAD_H */

