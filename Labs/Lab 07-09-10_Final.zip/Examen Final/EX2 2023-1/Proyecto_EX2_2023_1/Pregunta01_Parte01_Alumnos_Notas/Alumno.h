/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.h
 * Author: ISA
 *
 * Created on 16 de junio de 2024, 11:23 PM
 */

#ifndef ALUMNO_H
#define ALUMNO_H
#include <fstream>
using namespace std;

class Alumno {
private:
    int codigo_alumno;
    char *nombre;
    double promedio;
public:
    Alumno();
    Alumno(const Alumno& orig);
    virtual ~Alumno();
    void operator = (const Alumno& orig);
    void SetPromedio(double promedio);
    double GetPromedio() const;
    void SetCodigo_alumno(int codigo_alumno);
    int GetCodigo_alumno() const;

    void SetNombre(char *cad);
    void GetNombre(char *cad) const;

    bool operator << (ifstream &arch);
    bool cmp(const class Alumno& cmp)const;
    void imprimeAlumno(ofstream &arch)const;
};

#endif /* ALUMNO_H */

