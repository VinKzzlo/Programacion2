/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Facultad.h
 * Author: ISA
 *
 * Created on 17 de junio de 2024, 10:38 AM
 */

#ifndef FACULTAD_H
#define FACULTAD_H

#include <fstream>
using namespace std;
#include "ListaDoble.h"
class Facultad {
private:
    class ListaDoble alumnosxNotas;
    void leerAlumnos(const char* nomArch);
    void leerNotas(const char* nomArch);
public:
    Facultad();
    Facultad(const Facultad& orig);
    virtual ~Facultad();
    void leerAlumnosNotas(const char*,const char*);
    void imprimirAlumnosNotas(const char*);
};

#endif /* FACULTAD_H */

