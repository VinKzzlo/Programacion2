/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaDoble.h
 * Author: ISA
 *
 * Created on 16 de junio de 2024, 11:36 PM
 */

#ifndef LISTADOBLE_H
#define LISTADOBLE_H
#include <fstream>
using namespace std;
#include "Nodo.h"
class ListaDoble {
private:
    class Nodo *inicio;
    class Nodo *fin;
    bool noEsRepetido(int codigo);
public:
    ListaDoble();
    ListaDoble(const ListaDoble& orig);
    virtual ~ListaDoble();
    bool operator <= (ifstream &arch);
    void insertarOrdenado(const class AlumnoNotas & elemento);
//    alumnosxNotas <= arch
    void imprimeLista(ofstream &arch,bool sentido)const;
    void agregarNota(int codigo,const class Nota &dato);
};

#endif /* LISTADOBLE_H */

