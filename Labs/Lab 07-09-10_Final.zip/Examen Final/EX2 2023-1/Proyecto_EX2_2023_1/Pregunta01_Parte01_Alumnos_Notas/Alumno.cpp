/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Alumno.cpp
 * Author: ISA
 * 
 * Created on 16 de junio de 2024, 11:23 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "Alumno.h"

Alumno::Alumno() {
    codigo_alumno = 0;
    promedio = 0.0;
    nombre = nullptr;
}

Alumno::Alumno(const Alumno& orig) {
    (*this) = orig;
}

Alumno::~Alumno() {
    if (nombre != nullptr)delete nombre;
}
void Alumno::operator=(const Alumno& orig){
    codigo_alumno = orig.codigo_alumno;
    promedio = orig.promedio;
    nombre = nullptr;
    SetNombre(orig.nombre);
}
void Alumno::SetPromedio(double promedio) {
    this->promedio = promedio;
}

double Alumno::GetPromedio() const {
    return promedio;
}

void Alumno::SetCodigo_alumno(int codigo_alumno) {
    this->codigo_alumno = codigo_alumno;
}

int Alumno::GetCodigo_alumno() const {
    return codigo_alumno;
}
void Alumno::SetNombre(char *cad) {
    if (nombre != nullptr)delete nombre;
    nombre = new char[strlen(cad) + 1];
    strcpy(nombre, cad);
}

void Alumno::GetNombre(char *cad) const {
    if (nombre != nullptr)
        strcpy(cad, nombre);
}

bool Alumno::operator<<(ifstream &arch){
    arch >> codigo_alumno;
    if(arch.eof())return false;
    arch.get();
    char cadena[120];
    arch.getline(cadena,120);
    SetNombre(cadena);
    return true;
}

bool Alumno::cmp(const class Alumno& cmp)const{
//    return strcmp(nombre,cmp.nombre)>0;
    return codigo_alumno > cmp.codigo_alumno;
}

void Alumno::imprimeAlumno(ofstream &arch)const{
    arch << left << setw(10) 
            << codigo_alumno << setw(60) 
            << nombre << right << setw(10) 
            << promedio << endl;
}