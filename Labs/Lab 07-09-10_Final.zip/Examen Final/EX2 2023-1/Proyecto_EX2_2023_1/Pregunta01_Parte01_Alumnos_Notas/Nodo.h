/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.h
 * Author: ISA
 *
 * Created on 16 de junio de 2024, 11:34 PM
 */

#ifndef NODO_H
#define NODO_H
#include <fstream>
using namespace std;
#include "Alumno.h"
#include "Nota.h"
#include "AlumnoNotas.h"
#include "Nodo.h"
#include "ListaDoble.h"
class Nodo {
private:
    class AlumnoNotas dato;
    class Nodo *siguiente;
    class Nodo *anterior;
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    bool cmp(const class Nodo& cmp)const;
    friend class ListaDoble;
};

#endif /* NODO_H */

