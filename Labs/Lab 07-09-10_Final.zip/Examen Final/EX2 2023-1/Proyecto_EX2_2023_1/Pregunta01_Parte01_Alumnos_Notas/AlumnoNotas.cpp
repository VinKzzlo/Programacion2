/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AlumnoNotas.cpp
 * Author: ISA
 * 
 * Created on 16 de junio de 2024, 11:27 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;
#include <cstring>
#include "AlumnoNotas.h"
#define NO_ENCONTRADO -1
AlumnoNotas::AlumnoNotas() {
}

AlumnoNotas::AlumnoNotas(const AlumnoNotas& orig) {
    (*this) = orig;
}
AlumnoNotas::AlumnoNotas(const class Alumno& nuevo){
    (*this) <= nuevo;
}
AlumnoNotas::~AlumnoNotas() {
}

void AlumnoNotas::operator=(const AlumnoNotas& orig){
    alumno = orig.alumno;
    notas = orig.notas;
}

void AlumnoNotas::operator<=(const class Alumno &nuevo){
    alumno = nuevo;
}

bool AlumnoNotas::cmp(const class AlumnoNotas& cmp)const{
    return this->alumno.cmp(cmp.alumno);
}
int AlumnoNotas::GetCodigo_alumno()const{
    return alumno.GetCodigo_alumno();
}
void AlumnoNotas::SetPromedio(double promedio){
    alumno.SetPromedio(promedio);
}
double AlumnoNotas::GetPromedio() const{
    return alumno.GetPromedio();
}

void AlumnoNotas::agregarNota(const class Nota &dato){
    int cant_pre = notas.size(), cant_pos;
    notas.push_back(dato);
    cant_pos = notas.size();
    alumno.SetPromedio((alumno.GetPromedio() * cant_pre +
            dato.GetCalificacion()) / cant_pos);
//    char codigo[20];
//    dato.GetCodigo_curso(codigo);
//    int pos = buscarNota(codigo);
//    if(pos == NO_ENCONTRADO){
//        int cant_pre = notas.size(), cant_pos;
//        notas.push_back(dato);
//        cant_pos = notas.size();
//        alumno.SetPromedio((alumno.GetPromedio() * cant_pre +
//                dato.GetCalificacion()) / cant_pos);
//    }else{
//        notas[pos].SetVez(notas[pos].GetVez() + 1);
//    }
}
int AlumnoNotas::buscarNota(char *codigo)const{
    char aux[20];
    int i = 0;
    for(vector<class Nota>::const_iterator it = notas.begin();
            it != notas.end();it++){
        it.base()->GetCodigo_curso(aux);
        if(strcmp(codigo,aux)==0)return i;
        i++;
    }
    return NO_ENCONTRADO;
}
void AlumnoNotas::operator>=(ofstream &arch)const{
    alumno.imprimeAlumno(arch);
    arch << "Notas del alumno: " << endl;
    if(notas.size() != 0){
        for(const Nota &dato : notas){
            dato.imprimeNota(arch);
        }
    }else arch << "No hay notas" << endl;
}