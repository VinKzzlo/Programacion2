/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaDoble.cpp
 * Author: ISA
 * 
 * Created on 16 de junio de 2024, 11:36 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;
#include <cstring>
#include "Alumno.h"
#include "Nota.h"
#include "AlumnoNotas.h"
#include "Nodo.h"
#include "ListaDoble.h"

ListaDoble::ListaDoble() {
    fin = nullptr;
    inicio = nullptr;
}

ListaDoble::ListaDoble(const ListaDoble& orig) {
}

ListaDoble::~ListaDoble() {
}

bool ListaDoble::operator<=(ifstream &arch){
    class Alumno dato;
    if(dato << arch){
        if(noEsRepetido(dato.GetCodigo_alumno())){
            class AlumnoNotas elemento(dato);
            insertarOrdenado(elemento);
        }
        return true;
    }
    return false;
}
bool ListaDoble::noEsRepetido(int codigo){
    class Nodo *ptr = inicio;
    while (ptr != nullptr) {
        if (ptr->dato.GetCodigo_alumno() == codigo)return false;
        ptr = ptr->siguiente;
    }
    return true;
}
void ListaDoble::insertarOrdenado(const class AlumnoNotas & elemento){
    class Nodo *nuevo = new class Nodo,*actual = inicio,*anterior = nullptr;
    nuevo->dato = elemento;
    while(actual != nullptr){
        if(actual->cmp(*nuevo))break;
        anterior = actual;
        actual = actual->siguiente;
    }
    nuevo->siguiente = actual;
    nuevo->anterior = anterior;
    if(actual == nullptr)fin = nuevo;
    if(anterior == nullptr)inicio = nuevo;
    else{
        anterior->siguiente = nuevo;
        if(actual != nullptr)actual->anterior =nuevo;
    }
}

void ListaDoble::imprimeLista(ofstream &arch,bool sentido)const{
    class Nodo *ptr;
    if(sentido)ptr = inicio;
    else ptr = fin;
    while(ptr != nullptr){
        (ptr->dato) >= arch;
        arch << endl;
        if (sentido)ptr = ptr->siguiente;
        else ptr = ptr->anterior;
    }
}

void ListaDoble::agregarNota(int codigo,const class Nota &dato){
    class Nodo *ptr = inicio;
    while(ptr != nullptr){
        if(ptr->dato.GetCodigo_alumno() == codigo){
//            char aux[20];
//            dato.GetCodigo_curso(aux);
//            cout << setw(10) << aux;
            ptr->dato.agregarNota(dato);
            return;
        }
        ptr = ptr->siguiente;
    }
}