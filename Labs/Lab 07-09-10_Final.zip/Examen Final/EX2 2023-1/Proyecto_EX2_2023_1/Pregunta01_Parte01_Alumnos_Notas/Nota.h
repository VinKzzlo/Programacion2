/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.h
 * Author: ISA
 *
 * Created on 16 de junio de 2024, 11:19 PM
 */

#ifndef NOTA_H
#define NOTA_H
#include <fstream>
using namespace std;

class Nota {
private:
    int ciclo;
    char *codigo_curso;
    double creditos;
    int calificacion;
    int vez;
public:
    Nota();
    Nota(const Nota& orig);
    virtual ~Nota();
    void operator = (const Nota& orig);
    void SetVez(int vez);
    int GetVez() const;
    void SetCalificacion(int calificacion);
    int GetCalificacion() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    
    void SetCodigo_curso(char *cad);
    void GetCodigo_curso(char *cad) const;

    bool operator << (ifstream &arch);
    void imprimeNota (ofstream &arch)const;
};

#endif /* NOTA_H */

