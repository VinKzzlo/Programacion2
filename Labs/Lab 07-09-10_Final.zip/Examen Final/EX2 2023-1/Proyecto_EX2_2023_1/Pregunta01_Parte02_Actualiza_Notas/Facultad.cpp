/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Facultad.cpp
 * Author: ISA
 * 
 * Created on 17 de junio de 2024, 10:38 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;
#include <cstring>
#include "Alumno.h"
#include "Nota.h"
#include "AlumnoNotas.h"
#include "Nodo.h"
#include "ListaDoble.h"
#include "Facultad.h"

Facultad::Facultad() {
}

Facultad::Facultad(const Facultad& orig) {
}

Facultad::~Facultad() {
}

void Facultad::leerAlumnosNotas(const char* nomAlu, const char* nomNot){
    leerAlumnos(nomAlu);
    leerNotas(nomNot);
}

void Facultad::leerAlumnos(const char* nomArch){
    ifstream arch(nomArch,ios::in);
    if(!arch){
        cout << "Error en: " << nomArch << endl;
        exit(1);
    }
    while(alumnosxNotas <= arch);
}
void Facultad::leerNotas(const char* nomArch){
    ifstream arch(nomArch,ios::in);
    if(!arch){
        cout << "Error en: " << nomArch << endl;
        exit(1);
    }
    int ciclo,codigo;
    char c;
    class Nota dato;
    while(true){
        arch >> ciclo;
        if(arch.eof())break;
        arch >> c >> codigo >> c;
//        cout << codigo << ':';
        while(dato << arch){
            dato.SetCiclo(ciclo);
            alumnosxNotas.agregarNota(codigo,dato);
        }
//        cout << endl;
    }
}
void Facultad::actualizaNotas(){
    alumnosxNotas++;
}
void Facultad::imprimirAlumnosNotas(const char* nomRep){
    ofstream arch(nomRep, ios::out);
    if (!arch) {
        cout << "Error en: " << nomRep << endl;
        exit(1);
    }
    arch << setprecision(2) << fixed;
    alumnosxNotas.imprimeLista(arch,false);
}