
/* 
 * File:   main.cpp
 * Autor: Sebastian Grajeda
 * Codigo: 20210800
 * Created on 16 de junio de 2024, 11:17 PM
 */

#include "Facultad.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    class Facultad facultad;
    
    facultad.leerAlumnosNotas("Alumnos-Preg01.csv","Notas-Preg01.csv");
    facultad.actualizaNotas();
    facultad.imprimirAlumnosNotas("reporte.txt");
    return 0;
}

