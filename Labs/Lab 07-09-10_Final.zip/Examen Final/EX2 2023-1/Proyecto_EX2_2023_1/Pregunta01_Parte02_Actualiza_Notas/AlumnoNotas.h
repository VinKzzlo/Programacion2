/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AlumnoNotas.h
 * Author: ISA
 *
 * Created on 16 de junio de 2024, 11:27 PM
 */

#ifndef ALUMNONOTAS_H
#define ALUMNONOTAS_H
#include <fstream>
#include <vector>
using namespace std;
#include "Alumno.h"
#include "Nota.h"
class AlumnoNotas {
private:
    class Alumno alumno;
    vector<class Nota> notas;
    int buscarNota(char *codigo)const;
    int buscarNota2(vector<class Nota> &aux,char *codigo)const;
public:
    AlumnoNotas();
    AlumnoNotas(const AlumnoNotas& orig);
    AlumnoNotas(const class Alumno& nuevo);
    virtual ~AlumnoNotas();
    void operator = (const AlumnoNotas& orig);
    void operator <= (const class Alumno &nuevo);
    bool cmp(const class AlumnoNotas& cmp)const;
    int GetCodigo_alumno()const;
    void SetPromedio(double promedio);
    double GetPromedio() const;
    void agregarNota(const class Nota &dato);
    void operator >= (ofstream &arch)const;
    void actualizar();
    void totalizar();
};

#endif /* ALUMNONOTAS_H */

