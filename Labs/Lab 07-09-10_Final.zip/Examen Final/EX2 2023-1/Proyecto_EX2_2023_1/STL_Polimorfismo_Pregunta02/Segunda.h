/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Segunda.h
 * Author: ISA
 *
 * Created on 19 de junio de 2024, 09:43 AM
 */

#ifndef SEGUNDA_H
#define SEGUNDA_H
#include <fstream>
using namespace std;
#include "CursoAlumno.h"
#include "Primera.h"

class Segunda: public CursoAlumno{
private:
    double creditos;
public:
    Segunda();
    Segunda(const Segunda& orig);
    Segunda(const CursoAlumno& orig);
    virtual ~Segunda();
    void operator = (const Segunda& orig);
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void imprime(ofstream &arch);
};

#endif /* SEGUNDA_H */

