/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CursoAlumno.h
 * Author: ISA
 *
 * Created on 18 de junio de 2024, 02:54 PM
 */

#ifndef CURSOALUMNO_H
#define CURSOALUMNO_H
#include <fstream>
using namespace std;
class CursoAlumno {
private:
    int codigo;
    char *codcur;
    int ciclo;
    double creditos;
    int nota;
    int vez;
public:
    CursoAlumno();
    CursoAlumno(const CursoAlumno& orig);
    virtual ~CursoAlumno();
    void operator = (const CursoAlumno& orig);
    void SetVez(int vez);
    int GetVez() const;
    void SetNota(int nota);
    int GetNota() const;
    void SetCreditos(double creditos);
    double GetCreditos() const;
    void SetCiclo(int ciclo);
    int GetCiclo() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    
    void SetCodcur(char *cad);
    void GetCodcur(char *cad) const;
    bool lee(ifstream &arch);
    virtual void imprime(ofstream &arch);
    bool cmp(const CursoAlumno& orig)const;
};

#endif /* CURSOALUMNO_H */

