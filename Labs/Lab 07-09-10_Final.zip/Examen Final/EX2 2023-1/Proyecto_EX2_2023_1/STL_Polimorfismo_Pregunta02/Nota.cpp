/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.cpp
 * Author: ISA
 * 
 * Created on 19 de junio de 2024, 05:22 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "CursoAlumno.h"
#include "Primera.h"
#include "Segunda.h"
#include "Tercera.h"
#include "Nota.h"

Nota::Nota() {
    pnota = nullptr;
}

Nota::Nota(const Nota& orig) {
    (*this) *= orig;
}

Nota::~Nota() {
//    if(pnota != nullptr)delete pnota;
}
void Nota::operator*=(const Nota& orig){ //Pasar puntero
    pnota = orig.pnota;
}
void Nota::setNull(){
    pnota = nullptr;
}
bool Nota::isNull(){
    return pnota == nullptr;
}
bool Nota::operator<<=(ifstream &arch){
    pnota = new class Primera;
    return pnota->lee(arch);//Directo
}

void Nota::operator >>= (ofstream &arch){
    pnota->imprime(arch);
}

bool Nota::operator < (const Nota& cmp)const{
    return pnota->cmp(*(cmp.pnota));
}

int Nota::GetCiclo() const{
    return pnota->GetCiclo();
}
int Nota::GetCodigo() const{
    return pnota->GetCodigo();
}
void Nota::GetCodcur(char *cad) const{
    return pnota->GetCodcur(cad);
}

void Nota::operator++(int pivot){
    class CursoAlumno *aux = pnota;
    pnota = new class Segunda(*pnota);
    delete aux;
//    pnota->SetVez(pnota->GetVez()+1);
}
void Nota::operator++() {
    class CursoAlumno *aux = pnota;
    pnota = new class Tercera(*pnota);
    delete aux;
//    pnota->SetVez(pnota->GetVez() + 1);
}