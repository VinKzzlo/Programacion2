/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Registro.cpp
 * Author: ISA
 * 
 * Created on 19 de junio de 2024, 05:44 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
#include <cstring>
#include "Registro.h"
#include "Nota.h"

Registro::Registro() {
}

Registro::Registro(const Registro& orig) {
}

Registro::~Registro() {
}

void Registro::carga(){
    ifstream arch("registronotas.csv",ios::in);
    if(!arch){
        cout << "Error en: registronotas.csv" << endl;
        exit(1);
    }
    class Nota dato;
    while(dato <<= arch)
        vregistro.push_back(dato);
    dato.setNull();
}
void Registro::procesa(){
    sort(vregistro.begin(),vregistro.end());
    char cadI[20],cadK[20];
    for(int i = 0;i < vregistro.size()-1;i++){
        vregistro[i].GetCodcur(cadI);
        vregistro[i+1].GetCodcur(cadK);
//        cout << i << ' ' << cadI << " - " <<i+1 << ' ' << cadK << endl;
        if(vregistro[i].GetCodigo() == vregistro[i+1].GetCodigo() and 
                strcmp(cadI,cadK) == 0){
            if(i > 0 and vregistro[i-1].isNull()){
                ++vregistro[i+1]; //Trika <= Bika
            }else{
                vregistro[i+1]++; //Bika <= Prima
            }
            vregistro[i].setNull();
        }
    }
    Actualizar();
}
void Registro::Actualizar(){
    vector <class Nota> nuevo;
    for (vector<class Nota>::iterator it = vregistro.begin();
            it != vregistro.end(); it++) {
        if(not it->isNull()){
            nuevo.push_back(*it);
        }
    }
    vregistro = nuevo;
}
void Registro::muestra(){
    ofstream arch("reporte.txt",ios::out);
    if(!arch){
        cout << "Error en: reporte.txt" << endl;
        exit(1);
    }
    for(vector<class Nota>::iterator it = vregistro.begin();
            it != vregistro.end();it++){
        (*it) >>= arch;
//        arch << endl;
    }
        
}