/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tercera.h
 * Author: ISA
 *
 * Created on 19 de junio de 2024, 09:44 AM
 */

#ifndef TERCERA_H
#define TERCERA_H
#include <fstream>
using namespace std;
#include "CursoAlumno.h"
#include "Segunda.h"

class Tercera: public CursoAlumno{
private:
    double porcentaje;
public:
    Tercera();
    Tercera(const Tercera& orig);
    Tercera(const CursoAlumno& orig);
    virtual ~Tercera();
    void operator = (const Tercera& orig);
    void SetPorcentaje(double porcentaje);
    double GetPorcentaje() const;
    void imprime(ofstream &arch);
};

#endif /* TERCERA_H */

