/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CursoAlumno.cpp
 * Author: ISA
 * 
 * Created on 18 de junio de 2024, 02:54 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "CursoAlumno.h"

CursoAlumno::CursoAlumno() {
    ciclo = 0;
    codcur = nullptr;
    creditos = 0.0;
    nota = -1;
    vez = 0;
    codigo = 0;
}

CursoAlumno::CursoAlumno(const CursoAlumno& orig) {
    (*this) = orig;
}

CursoAlumno::~CursoAlumno() {
    if(codcur != nullptr)delete codcur;
}
void CursoAlumno::operator=(const CursoAlumno& orig){
    ciclo = orig.ciclo;
    codcur = nullptr;
    SetCodcur(orig.codcur);
    creditos = orig.creditos;
    nota = orig.nota;
    vez = orig.vez;
    codigo = orig.codigo;
}
void CursoAlumno::SetVez(int vez) {
    this->vez = vez;
}

int CursoAlumno::GetVez() const {
    return vez;
}

void CursoAlumno::SetNota(int nota) {
    this->nota = nota;
}

int CursoAlumno::GetNota() const {
    return nota;
}

void CursoAlumno::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double CursoAlumno::GetCreditos() const {
    return creditos;
}

void CursoAlumno::SetCiclo(int ciclo) {
    this->ciclo = ciclo;
}

int CursoAlumno::GetCiclo() const {
    return ciclo;
}

void CursoAlumno::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int CursoAlumno::GetCodigo() const {
    return codigo;
}

void CursoAlumno::SetCodcur(char *cad){
    if(codcur != nullptr)delete codcur;
    codcur = new char[strlen(cad)+1];
    strcpy(codcur,cad);
}
void CursoAlumno::GetCodcur(char *cad) const{
    if(codcur != nullptr)
        strcpy(cad,codcur);
}

bool CursoAlumno::lee(ifstream &arch){
    arch >> codigo;
    if(arch.eof())return false;
    char cadena[20],c;
    arch.get();
    arch.getline(cadena,20,',');
    SetCodcur(cadena);
    arch >> creditos >> c >> ciclo >> c >> nota;
    return true;
}

void CursoAlumno::imprime(ofstream &arch){
    arch << left << setw(10) 
            << codigo << setw(14) 
            << codcur << setw(10) 
            << ciclo << right << setw(8) 
            << nota << setw(8) 
            << vez << setw(8) 
            << creditos;
}

bool CursoAlumno::cmp(const CursoAlumno& orig)const{
    return codigo < orig.codigo or (codigo == orig.codigo and strcmp(codcur,orig.codcur) < 0
            or (codigo == orig.codigo and strcmp(codcur,orig.codcur) == 0 and 
            ciclo < orig.ciclo));
}