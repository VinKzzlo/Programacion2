
/* 
 * File:   main.cpp
 * Autor: Sebastian Grajeda
 * Codigo: 20210800
 * Created on 18 de junio de 2024, 02:38 PM
 */

#include "Registro.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Registro reg;
    
    reg.carga();
    reg.procesa();
    reg.muestra();
    
    return 0;
}

