/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Primera.cpp
 * Author: ISA
 * 
 * Created on 19 de junio de 2024, 09:31 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "Primera.h"

Primera::Primera() {
    codacceso = nullptr;
}

Primera::Primera(const Primera& orig) {
}

Primera::~Primera() {
    if (codacceso != nullptr)delete codacceso;
}
void Primera::operator=(const Primera& orig){
    CursoAlumno::operator =(orig);
    codacceso = nullptr;
    if(orig.codacceso != nullptr)
        SetCodacceso(orig.codacceso);
}
void Primera::SetCodacceso(char *cad) {
    if (codacceso != nullptr)delete codacceso;
    codacceso = new char[strlen(cad) + 1];
    strcpy(codacceso, cad);
}

void Primera::GetCodacceso(char *cad) const {
    if (codacceso != nullptr)
        strcpy(cad, codacceso);
}

void Primera::imprime(ofstream &arch){
    CursoAlumno::imprime(arch);
    if(codacceso != nullptr) arch << setw(10) << codacceso;
    arch << endl;
}