/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nota.h
 * Author: ISA
 *
 * Created on 19 de junio de 2024, 05:22 PM
 */

#ifndef NOTA_H
#define NOTA_H
#include <fstream>
using namespace std;
#include "CursoAlumno.h"
class Nota {
private:
    class CursoAlumno *pnota;
public:
    Nota();
    Nota(const Nota& orig);
    virtual ~Nota();
    void operator *= (const Nota& orig);
    bool isNull();
    void setNull();
    bool operator <<= (ifstream &arch);
//    dato <<= arch
    void operator >>= (ofstream &arch);
//    (*it) >>= arch;
    bool operator < (const Nota& cmp)const;
    int GetCiclo() const;
    int GetCodigo() const;
    void GetCodcur(char *cad) const;
    
    void operator ++ (int pivot);
    void operator ++ ();
};

#endif /* NOTA_H */

