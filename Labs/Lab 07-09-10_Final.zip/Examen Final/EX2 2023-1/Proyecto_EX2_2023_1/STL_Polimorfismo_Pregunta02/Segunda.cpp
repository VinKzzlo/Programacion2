/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Segunda.cpp
 * Author: ISA
 * 
 * Created on 19 de junio de 2024, 09:43 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "CursoAlumno.h"
#include "Segunda.h"

Segunda::Segunda() {
    creditos = 0.0;
}

Segunda::Segunda(const Segunda& orig) {
    (*this) = orig;
}
Segunda::Segunda(const CursoAlumno& orig){
    CursoAlumno::operator =(orig);
    if(orig.GetCreditos() <= 3.0)creditos = 1.0;
    else creditos = 1.5;
    SetVez(1);
}
Segunda::~Segunda() {
}
void Segunda::operator=(const Segunda& orig){
    CursoAlumno::operator =(orig);
    creditos = orig.creditos;
}
void Segunda::SetCreditos(double creditos) {
    this->creditos = creditos;
}

double Segunda::GetCreditos() const {
    return creditos;
}

void Segunda::imprime(ofstream &arch) {
    CursoAlumno::imprime(arch);
    arch << endl;
}