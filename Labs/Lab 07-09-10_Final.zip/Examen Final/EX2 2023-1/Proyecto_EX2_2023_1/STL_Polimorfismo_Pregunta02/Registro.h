/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Registro.h
 * Author: ISA
 *
 * Created on 19 de junio de 2024, 05:44 PM
 */

#ifndef REGISTRO_H
#define REGISTRO_H
#include <fstream>
#include <vector>
using namespace std;
#include "Nota.h"
class Registro {
private:
    vector<class Nota> vregistro;
    void Actualizar();
public:
    Registro();
    Registro(const Registro& orig);
    virtual ~Registro();
    void carga();
    void procesa();
    void muestra();
};

#endif /* REGISTRO_H */

