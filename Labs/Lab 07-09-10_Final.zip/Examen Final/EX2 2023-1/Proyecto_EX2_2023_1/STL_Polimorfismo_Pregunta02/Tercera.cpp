/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tercera.cpp
 * Author: ISA
 * 
 * Created on 19 de junio de 2024, 09:44 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include <cstring>
#include "CursoAlumno.h"
#include "Tercera.h"

Tercera::Tercera() {
    porcentaje = 0.0;
}

Tercera::Tercera(const Tercera& orig) {
    (*this) = orig;
}
Tercera::Tercera(const CursoAlumno& orig){
    CursoAlumno::operator =(orig);
    if (orig.GetCreditos() <= 3.0)porcentaje = 0.50;
    else porcentaje = 1.00;
    SetVez(2);
}
Tercera::~Tercera() {
}
void Tercera::operator=(const Tercera& orig){
    CursoAlumno::operator =(orig);
    porcentaje = orig.porcentaje;
}

void Tercera::SetPorcentaje(double porcentaje) {
    this->porcentaje = porcentaje;
}

double Tercera::GetPorcentaje() const {
    return porcentaje;
}

void Tercera::imprime(ofstream &arch) {
    CursoAlumno::imprime(arch);
    arch << endl;
}