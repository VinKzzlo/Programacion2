/* 
 * File:   Nodo.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:52 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Nodo.h"
#include "Pedido.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
private:
    Pedido *ped;
    Nodo *sig;
};

#endif /* NODO_H */

