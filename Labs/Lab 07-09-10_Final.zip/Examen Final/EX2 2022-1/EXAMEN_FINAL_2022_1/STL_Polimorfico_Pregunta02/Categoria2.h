/* 
 * File:   Categoria2.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:50 AM
 */

#ifndef CATEGORIA2_H
#define CATEGORIA2_H

#include "Producto.h"

class Categoria2:public Producto {
public:
    Categoria2();
    Categoria2(const Categoria2& orig);
    virtual ~Categoria2();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void lee(ifstream &);
    int Prioridad();
    void imprime(ofstream &);
private:
    int prioridad;
    double descuento;
};

#endif /* CATEGORIA2_H */

