/* 
 * File:   Pedido.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:47 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetOrden(int orden);
    int GetOrden() const;
    void SetTotal(double total);
    double GetTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetDni(int dni);
    int GetDni() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void leerDatos(ifstream &);
    void imprime(ofstream &);
private:
    int codigo;
    int cantidad;
    int dni;
    int fecha;
    double total;
    int orden;
};

#endif /* PEDIDO_H */

