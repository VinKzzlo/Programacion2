/* 
 * File:   Producto.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:49 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Producto.h"

Producto::Producto() {
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetNombre(string nombre) {
    this->nombre = nombre;
}

string Producto::GetNombre() const {
    return nombre;
}

void Producto::SetCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::GetCodprod() const {
    return codprod;
}
//412041,TORTILLAS DE MAIZ 1KG,15
void Producto::lee(ifstream &archProd){
    archProd>>codprod;
    archProd.get();
    getline(archProd,nombre,',');
    archProd>>stock;
}

void Producto::imprime(ofstream &archRep){
    archRep<<left<<setw(8)<<codprod<<setw(40)<<nombre<<right<<setw(10)<<stock;
}