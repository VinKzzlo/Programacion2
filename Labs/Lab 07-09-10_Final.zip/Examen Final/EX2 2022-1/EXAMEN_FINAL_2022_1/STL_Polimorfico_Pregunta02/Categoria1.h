/* 
 * File:   Categoria1.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:49 AM
 */

#ifndef CATEGORIA1_H
#define CATEGORIA1_H

#include "Producto.h"

class Categoria1:public Producto {
public:
    Categoria1();
    Categoria1(const Categoria1& orig);
    virtual ~Categoria1();
    void SetMinimo(int minimo);
    int GetMinimo() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void lee(ifstream &);
    int Prioridad();
    void imprime(ofstream &);
private:
    int prioridad;
    int minimo;
};

#endif /* CATEGORIA1_H */

