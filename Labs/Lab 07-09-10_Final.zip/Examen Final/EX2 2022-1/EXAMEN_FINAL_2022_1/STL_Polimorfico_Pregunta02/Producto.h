/* 
 * File:   Producto.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:49 AM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetStock(int stock);
    int GetStock() const;
    void SetNombre(string nombre);
    string GetNombre() const;
    void SetCodprod(int codprod);
    int GetCodprod() const;
    virtual void lee(ifstream &);
    virtual int Prioridad()=0;
    virtual void imprime(ofstream &);
private:
    int codprod;
    string nombre;
    int stock;
};

#endif /* PRODUCTO_H */

