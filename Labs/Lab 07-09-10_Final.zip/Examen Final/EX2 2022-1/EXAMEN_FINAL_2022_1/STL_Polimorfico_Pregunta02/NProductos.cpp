/* 
 * File:   NProductos.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:52 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "NProductos.h"
#include "Categoria1.h"
#include "Categoria2.h"
#include "Categoria3.h"

NProductos::NProductos() {
    prod = nullptr;
}

NProductos::NProductos(const NProductos& orig) {
    this->prod = orig.prod;
}

NProductos::~NProductos() {
}

int NProductos::GetCodigo() const{
    return prod->GetCodprod();
}

int NProductos::GetPrioridad() const{
    return prod->Prioridad();
}

void NProductos::leerDatos(ifstream &archProd){
    prod->lee(archProd);
}

void NProductos::asignaMemoria(int categoria){
    if(categoria==1) prod = new Categoria1;
    else if(categoria==2) prod = new Categoria2;
    else if(categoria==3) prod = new Categoria3;
}

void NProductos::imprimeProducto(ofstream &archRep){
    prod->imprime(archRep);
}