/* 
 * File:   Categoria3.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:51 AM
 */

#ifndef CATEGORIA3_H
#define CATEGORIA3_H

#include "Producto.h"

class Categoria3:public Producto {
public:
    Categoria3();
    Categoria3(const Categoria3& orig);
    virtual ~Categoria3();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void lee(ifstream &);
    int Prioridad();
    void imprime(ofstream &);
private:
    int prioridad;
    double descuento;
};

#endif /* CATEGORIA3_H */

