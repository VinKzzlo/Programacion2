/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 7 de julio de 2024, 01:47 AM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programa.h"
int main(int argc, char** argv) {
    
    Programa pro;
    
    pro.carga();
    pro.actualiza();
    pro.muestra();
    
    return 0;
}

