/* 
 * File:   Programa.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:54 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programa.h"

Programa::Programa() {
}

Programa::Programa(const Programa& orig) {
}

Programa::~Programa() {
}

void Programa::carga(){
    CargaProductos("productos4.csv");
    CargaLista("pedidos4.csv");
}
/*
1,0,10,412041,TORTILLAS DE MAIZ 1KG,15
1,0,10,690039,CORAZONES DE OREJONA PZA,11
*/
void Programa::CargaProductos(const char *nombArch){
    ifstream archProd(nombArch,ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int categoria;
    NProductos nprod;
    while(1){
        archProd>>categoria;
        if(archProd.eof()) break;
        archProd.get();
        nprod.asignaMemoria(categoria);
        nprod.leerDatos(archProd);
        vproductos.push_back(nprod);
    }
}

void Programa::CargaLista(const char *nombArch){
    ifstream archPed(nombArch,ios::in);
    if(not archPed.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    lpedidos.creaLista(archPed);
}

void Programa::actualiza(){
    int codProd[200],prior[200],n;
    NProductos nprod;
    lpedidos.obtenerCodigos(codProd,n);
    for(int i=0;i<n;i++)
        for(int j=0;j<vproductos.size();j++)
            if(codProd[i]==vproductos[j].GetCodigo()){
                prior[i] = vproductos[j].GetPrioridad();
                break;
            }
    lpedidos.reordena(prior);
}

void Programa::muestra(){
    ImprimeProductos("ListaDeProductos.txt");
    ImprimePedidos("ListaDePedidos.txt");
}

void Programa::ImprimeProductos(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    for(int i=0;i<vproductos.size();i++){
        vproductos[i].imprimeProducto(archRep);
    }
}

void Programa::ImprimePedidos(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    lpedidos.imprimeLista(archRep);
}