/* 
 * File:   Lista.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:53 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Lista.h"

Lista::Lista() {
    lini = nullptr;
    lfin = nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}
/*
118050,8,8,79475585,16/12/2021
118050,5,5,79475585,30/04/2021
*/
void Lista::creaLista(ifstream &archPed){
    Nodo *nuevo;
    while(1){
        nuevo = new Nodo;
        nuevo->ped = new Pedido;
        nuevo->ped->leerDatos(archPed);
        if(archPed.eof()) break;
        insertar(nuevo);
    }
}

void Lista::insertar(class Nodo *nuevo){
    Nodo *p = lini, *ant = nullptr;
    if(lini==nullptr){
        lini = nuevo;
        lfin = nuevo;
    }else{
        while(p){
            if(p->ped->GetFecha() > nuevo->ped->GetFecha()) break;
            ant = p;
            p = p->sig;
        }
        nuevo->sig = p;
        
        if(ant) ant->sig = nuevo;
        else lini = nuevo;
        
        if(p==nullptr) lfin = nuevo;
    }
}

void Lista::obtenerCodigos(int *codProd,int &n){
    Nodo *p = lini;
    n=0;
    while(p){
        codProd[n] = p->ped->GetCodigo();
        p = p->sig;
        n++;
    }
}

void Lista::reordena(int *prior){
    Nodo *p = lini->sig, *ant = lini;
    int i=1;
    while(p){
        if(prior[i]==1){
            p->ped->SetOrden(1);
            ant->sig = p->sig;
            p->sig = lini;
            lini = p;
            p = ant->sig;
            if(p==nullptr) lfin = ant;
        }else{
            p->ped->SetOrden(0);
            ant = p;
            p = p->sig;
        }
        i++;
    }
}

void Lista::imprimeLista(ofstream &archRep){
    Nodo *p = lini;
    while(p){
        p->ped->imprime(archRep);
        p = p->sig;
    }
}