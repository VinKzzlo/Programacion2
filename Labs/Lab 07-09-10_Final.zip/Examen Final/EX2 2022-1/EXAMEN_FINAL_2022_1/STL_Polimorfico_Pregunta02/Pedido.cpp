/* 
 * File:   Pedido.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:47 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    cantidad = 0;
    dni = 0;
    fecha = 0;
    total = 0.0;
    orden = 0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetOrden(int orden) {
    this->orden = orden;
}

int Pedido::GetOrden() const {
    return orden;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}
//118050,8,8,79475585,16/12/2021
void Pedido::leerDatos(ifstream &archPed){
    int dd,mm,aa;
    char c;
    
    archPed>>codigo;
    if(archPed.eof()) return;
    archPed.get();
    archPed>>cantidad>>c>>total>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
    SetFecha(aa*10000+mm*100+dd);
}

void Pedido::imprime(ofstream &archRep){
    int dd = fecha%100;
    int mm = (fecha/100)%100;
    int aa = fecha/10000;
    archRep<<fixed<<setprecision(2);
    archRep<<right<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)<<mm<<'/'<<setw(4)
           <<aa<<setfill(' ')<<setw(10)<<codigo<<setw(10)<<cantidad<<setw(10)
           <<total;
    if(orden==0) archRep<<setw(10)<<"No"<<endl;
    else         archRep<<setw(10)<<"Si"<<endl;
}