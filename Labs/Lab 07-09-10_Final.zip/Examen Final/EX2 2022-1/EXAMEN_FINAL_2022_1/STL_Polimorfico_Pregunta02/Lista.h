/* 
 * File:   Lista.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:53 AM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"

class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void creaLista(ifstream &);
    void obtenerCodigos(int*,int&);
    void reordena(int*);
    void imprimeLista(ofstream &);
private:
    Nodo *lini;
    Nodo *lfin;
    void insertar(class Nodo*);
    //Ordenada por fecha / Lista simple
};

#endif /* LISTA_H */

