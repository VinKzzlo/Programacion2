/* 
 * File:   Programa.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:54 AM
 */

#ifndef PROGRAMA_H
#define PROGRAMA_H

#include <vector>

#include "Lista.h"
#include "NProductos.h"

class Programa {
public:
    Programa();
    Programa(const Programa& orig);
    virtual ~Programa();
    void carga();
    void actualiza();
    void muestra();
private:
    Lista lpedidos;
    vector<class NProductos>vproductos;
    void CargaProductos(const char*);
    void CargaLista(const char*);
    void ImprimeProductos(const char*);
    void ImprimePedidos(const char*);
};

#endif /* PROGRAMA_H */

