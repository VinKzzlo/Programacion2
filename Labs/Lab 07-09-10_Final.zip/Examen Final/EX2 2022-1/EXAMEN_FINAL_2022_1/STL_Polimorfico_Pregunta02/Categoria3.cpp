/* 
 * File:   Categoria3.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:51 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Categoria3.h"

Categoria3::Categoria3() {
    prioridad = 0;
    descuento = 0.0;
}

Categoria3::Categoria3(const Categoria3& orig) {
}

Categoria3::~Categoria3() {
}

void Categoria3::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria3::GetDescuento() const {
    return descuento;
}

void Categoria3::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria3::GetPrioridad() const {
    return prioridad;
}

void Categoria3::lee(ifstream &archProd){
    char c;
    
    archProd>>prioridad>>c>>descuento>>c;
    Producto::lee(archProd);
}

int Categoria3::Prioridad(){
    return prioridad;
}

void Categoria3::imprime(ofstream &archRep){
    Producto::imprime(archRep);
    archRep<<right<<setw(6)<<prioridad<<setw(10)<<descuento<<endl;
}