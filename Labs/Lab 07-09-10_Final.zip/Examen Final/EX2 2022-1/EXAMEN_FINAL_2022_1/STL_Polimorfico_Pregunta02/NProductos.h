/* 
 * File:   NProductos.h
 * Author: ramir
 *
 * Created on 7 de julio de 2024, 01:52 AM
 */

#ifndef NPRODUCTOS_H
#define NPRODUCTOS_H

#include "Producto.h"

class NProductos {
public:
    NProductos();
    NProductos(const NProductos& orig);
    virtual ~NProductos();
    void leerDatos(ifstream &);
    void asignaMemoria(int);
    int GetCodigo() const;
    int GetPrioridad() const;
    void imprimeProducto(ofstream &);
private:
    Producto *prod;
};

#endif /* NPRODUCTOS_H */

