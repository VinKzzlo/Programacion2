/* 
 * File:   Categoria2.cpp
 * Author: ramir
 * 
 * Created on 7 de julio de 2024, 01:50 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Categoria2.h"

Categoria2::Categoria2() {
    prioridad = 0;
    descuento = 0.0;
}

Categoria2::Categoria2(const Categoria2& orig) {
}

Categoria2::~Categoria2() {
}

void Categoria2::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria2::GetDescuento() const {
    return descuento;
}

void Categoria2::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria2::GetPrioridad() const {
    return prioridad;
}

void Categoria2::lee(ifstream &archProd){
    char c;
    
    archProd>>prioridad>>c>>descuento>>c;
    Producto::lee(archProd);
}

int Categoria2::Prioridad(){
    return prioridad;
}

void Categoria2::imprime(ofstream &archRep){
    Producto::imprime(archRep);
    archRep<<right<<setw(6)<<prioridad<<setw(10)<<descuento<<endl;
}