/* 
 * File:   Pedido.cpp
 * Author: ramir
 * 
 * Created on 6 de julio de 2024, 09:22 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    cantidad = 0.0;
    fecha = 0;
    subTotal = 0.0;
}

Pedido::Pedido(const Pedido& orig) {
    this->codigo = orig.codigo;
    this->cantidad = orig.cantidad;
    this->fecha = orig.fecha;
    this->subTotal = orig.subTotal;
}

Pedido::~Pedido() {
}

void Pedido::SetSubTotal(double subTotal) {
    this->subTotal = subTotal;
}

double Pedido::GetSubTotal() const {
    return subTotal;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetCantidad(double cantidad) {
    this->cantidad = cantidad;
}

double Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::imprimirDatos(ofstream &archRep){
    archRep<<fixed<<setprecision(2);
    int dd = fecha%100;
    int mm = (fecha/100)%100;
    int aa = fecha/10000;
    archRep<<right<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)<<mm<<'/'<<setw(4)
           <<aa<<setfill(' ')<<setw(10)<<codigo<<setw(10)<<cantidad<<setw(10)
           <<subTotal<<endl;
}
//7.56,79140840,27/05/2019
int Pedido::leerDatos(ifstream &archPed){
    int dni,dd,mm,aa;
    char c;
    
    archPed>>cantidad>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
    SetFecha(aa*10000+mm*100+dd);
    archPed.get();
    
    return dni;
}

bool Pedido::operator < (const class Pedido &ped){
    return fecha < ped.fecha;   //Comparando fecha
}