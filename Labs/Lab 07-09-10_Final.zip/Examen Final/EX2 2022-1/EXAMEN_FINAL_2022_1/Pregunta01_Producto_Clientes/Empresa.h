/* 
 * File:   Empresa.h
 * Author: ramir
 *
 * Created on 6 de julio de 2024, 09:23 PM
 */

#ifndef EMPRESA_H
#define EMPRESA_H

#include <list>

#include "Producto.h"
#include "RegCliente.h"

class Empresa {
public:
    Empresa();
    Empresa(const Empresa& orig);
    virtual ~Empresa();
    void leerClientes(const char*);
    void imprimirClientes(const char*);
    void leerPedidos(const char*);
    void ordenarPedidos();
    void imprimirProductos(const char*);
    list<class Producto>::iterator buscarProducto(int);
    list<class RegCliente>::iterator buscarCliente(int);
private:
    list<class Producto>lstProductos;
    list<class RegCliente>lstClientes;
};

#endif /* EMPRESA_H */

