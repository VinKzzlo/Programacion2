/* 
 * File:   Empresa.cpp
 * Author: ramir
 * 
 * Created on 6 de julio de 2024, 09:23 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Empresa.h"

Empresa::Empresa() {
}

Empresa::Empresa(const Empresa& orig) {
}

Empresa::~Empresa() {
}
/*
71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO B,935441620
29847168,ALDAVE ZEVALLOS ROSARIO A,6261108
32821689,ZAVALETA EPIQUEN CARMEN ZKENIA C,955248211
91897732,GAMARRA ALCOCER VIRGINIA,954025615
*/
void Empresa::leerClientes(const char *nombArch){
    ifstream archCli(nombArch,ios::in);
    if(not archCli.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    RegCliente regcli;
    while(1){
        regcli.leerDatos(archCli);
        if(archCli.eof()) break;
        lstClientes.push_back(regcli);
    }
}

void Empresa::imprimirClientes(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    for(list<class RegCliente>::iterator
            it=lstClientes.begin();         it!=lstClientes.end();      it++){
        it->imprimeDatos(archRep);
    }
}
/*
311343,YOGHURT FRESA NESTLE 1KG,%12.73,23.27,7.56,79140840,27/05/2019
696000,MEDIA CREMA NESTLE 1LT,%1.35,40.8,5.32,79475585,26/06/2020
*/
void Empresa::leerPedidos(const char *nombArch){
    ifstream archPed(nombArch,ios::in);
    if(not archPed.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int dni;
    Producto prod;
    Pedido ped;
    list<class Producto>::iterator itPosProd;
    list<class RegCliente>::iterator itPosCli;
    while(1){
        //Primero leemos los datos del producto
        prod.leerDatos(archPed);
        if(archPed.eof()) break;
        //Luego verificamos que no hay productos repetidos
        itPosProd = buscarProducto(prod.GetCodigo());
        if(itPosProd==lstProductos.end())   //Producto no fue encontrado
            lstProductos.push_back(prod);   //Se agrega
        //Leer pedido
        dni = ped.leerDatos(archPed);
        //Agregar info al cliente
        itPosCli = buscarCliente(dni);
        if(itPosCli!=lstClientes.end()){    //Llenamos datos del pedido
            ped.SetCodigo(prod.GetCodigo());
            ped.SetSubTotal(prod.GetPrecioUnitario()*ped.GetCantidad()*
                            (1-prod.GetDescuento()/100)*
                            (1-itPosCli->GetDescuento()/100));
            //cantidad X precio X descProd X descTipoCli
        }
        itPosCli->agregarPedido(ped);
    }
}

list<class Producto>::iterator Empresa::buscarProducto(int codigo){
    for(list<class Producto>::iterator
            it=lstProductos.begin();    it!=lstProductos.end();     it++){
        if(it->GetCodigo()==codigo) return it;
    }
    return lstProductos.end();
}

list<class RegCliente>::iterator Empresa::buscarCliente(int dni){
    for(list<class RegCliente>::iterator
            it=lstClientes.begin();     it!=lstClientes.end();      it++){
        if(it->GetDni()==dni) return it;
    }
    return lstClientes.end();
}

void Empresa::ordenarPedidos(){
    for(list<class RegCliente>::iterator
            it=lstClientes.begin();         it!=lstClientes.end();  it++){
        it->ordenaPedidos();
    }
}

void Empresa::imprimirProductos(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    for(list<class Producto>::iterator
            it=lstProductos.begin();    it!=lstProductos.end();     it++){
        it->imprimirDatos(archRep);
    }
}