/* 
 * File:   Pedido.h
 * Author: ramir
 *
 * Created on 6 de julio de 2024, 09:22 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetSubTotal(double subTotal);
    double GetSubTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetCantidad(double cantidad);
    double GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void imprimirDatos(ofstream &);
    int leerDatos(ifstream &);
    bool operator < (const class Pedido &);
private:
    int codigo;
    double cantidad;
    int fecha;
    double subTotal;
};

#endif /* PEDIDO_H */

