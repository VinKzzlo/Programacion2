/* 
 * File:   RegCliente.h
 * Author: ramir
 *
 * Created on 6 de julio de 2024, 09:23 PM
 */

#ifndef REGCLIENTE_H
#define REGCLIENTE_H

#include <list>

#include "Cliente.h"
#include "Pedido.h"

class RegCliente {
public:
    RegCliente();
    RegCliente(const RegCliente& orig);
    virtual ~RegCliente();
    int GetDni() const;
    double GetDescuento() const;
    void leerDatos(ifstream &);
    void imprimeDatos(ofstream &);
    void agregarPedido(class Pedido &);
    void ordenaPedidos();
private:
    Cliente cliente;
    list<class Pedido>pedidos;
};

#endif /* REGCLIENTE_H */

