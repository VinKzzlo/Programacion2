/* 
 * File:   RegCliente.cpp
 * Author: ramir
 * 
 * Created on 6 de julio de 2024, 09:23 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "RegCliente.h"

RegCliente::RegCliente() {
}

RegCliente::RegCliente(const RegCliente& orig) {
    *this = orig;
}

RegCliente::~RegCliente() {
}

int RegCliente::GetDni() const{
    return cliente.GetDni();
}

double RegCliente::GetDescuento() const{
    return cliente.GetDescuento();
}

void RegCliente::leerDatos(ifstream &archCli){
    cliente.leerDatos(archCli);
    if(archCli.eof()) return;
    switch(cliente.GetTipo()){
        case 'A':
            cliente.SetDescuento(23.5);
            break;
        case 'B':
            cliente.SetDescuento(16.8);
            break;
        case 'C':
            cliente.SetDescuento(8.3);
            break;
        default:
            break;
    }
}

void RegCliente::imprimeDatos(ofstream &archRep){
    cliente.imprimirDatos(archRep);
    for(list<class Pedido>::iterator
            it=pedidos.begin();         it!=pedidos.end();      it++){
        (*it).imprimirDatos(archRep);
    }
}

void RegCliente::agregarPedido(class Pedido &ped){
    pedidos.push_back(ped);
}

void RegCliente::ordenaPedidos(){
    pedidos.sort();
}