/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 6 de julio de 2024, 09:20 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Empresa.h"
int main(int argc, char** argv) {
    
    Empresa empresa;
    empresa.leerClientes("Clientes.csv");
    empresa.imprimirClientes("PruebaClientes.txt");
    empresa.leerPedidos("Pedidos.csv");
    empresa.ordenarPedidos();
    empresa.imprimirProductos("ReporteDeProductos.txt");
    empresa.imprimirClientes("ReporteDeClientes.txt");
    
    return 0;
}

