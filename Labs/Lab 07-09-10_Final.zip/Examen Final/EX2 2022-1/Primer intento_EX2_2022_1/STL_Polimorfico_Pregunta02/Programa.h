/* 
 * File:   Programa.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:55 AM
 */

#ifndef PROGRAMA_H
#define PROGRAMA_H

#include <vector>

#include "Lista.h"

class Programa {
public:
    Programa();
    Programa(const Programa& orig);
    virtual ~Programa();
    void carga();
    void muestra();
    void actualiza();
private:
    Lista lpedidos;
    vector<class NProductos>vproductos;
    void cargaProductos();
    void cargaLista();
    void imprimeProductos();
    void imprimePedidos();
};

#endif /* PROGRAMA_H */

