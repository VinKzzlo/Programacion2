/* 
 * File:   Categoria3.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:51 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Categoria3.h"

Categoria3::Categoria3() {
    prioridad = 0;
    descuento = 0.0;
}

Categoria3::Categoria3(const Categoria3& orig) {
}

Categoria3::~Categoria3() {
}

void Categoria3::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria3::GetDescuento() const {
    return descuento;
}

void Categoria3::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria3::GetPrioridad() const {
    return prioridad;
}
//1,40,459032,GELATINA DANY LIMON 125GR,24
void Categoria3::leer(ifstream &archProd){
    char c;
    
    archProd>>prioridad>>c>>descuento>>c;
    Producto::leer(archProd);
}

void Categoria3::imprime(ofstream &archRep){
    archRep<<fixed<<setprecision(2);
    Producto::imprime(archRep);
    archRep<<right<<setw(6)<<prioridad<<setw(10)<<descuento<<endl;
}

int Categoria3::GetPrioridad(){
    return prioridad;
}