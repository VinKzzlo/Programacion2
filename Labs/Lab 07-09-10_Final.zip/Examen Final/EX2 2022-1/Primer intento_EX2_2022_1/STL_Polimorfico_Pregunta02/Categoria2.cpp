/* 
 * File:   Categoria2.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:50 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Categoria2.h"

Categoria2::Categoria2() {
    prioridad = 0;
    descuento = 0.0;
}

Categoria2::Categoria2(const Categoria2& orig) {
}

Categoria2::~Categoria2() {
}

void Categoria2::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria2::GetDescuento() const {
    return descuento;
}

void Categoria2::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria2::GetPrioridad() const {
    return prioridad;
}
//0,25,580927,TORTILLAS DE HARINA DEL HOGAR 22P. 840GR,6
void Categoria2::leer(ifstream &archProd){
    char c;
    
    archProd>>prioridad>>c>>descuento>>c;
    Producto::leer(archProd);
}

void Categoria2::imprime(ofstream &archRep){
    archRep<<fixed<<setprecision(2);
    Producto::imprime(archRep);
    archRep<<right<<setw(6)<<prioridad<<setw(10)<<descuento<<endl;
}

int Categoria2::GetPrioridad(){
    return prioridad;
}