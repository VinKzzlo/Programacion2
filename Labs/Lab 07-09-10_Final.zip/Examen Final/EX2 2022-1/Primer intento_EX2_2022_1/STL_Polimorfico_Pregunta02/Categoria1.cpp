/* 
 * File:   Categoria1.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:49 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Categoria1.h"

Categoria1::Categoria1() {
    prioridad = 0;
    minimo = 0;
}

Categoria1::Categoria1(const Categoria1& orig) {
}

Categoria1::~Categoria1() {
}

void Categoria1::SetMinimo(int minimo) {
    this->minimo = minimo;
}

int Categoria1::GetMinimo() const {
    return minimo;
}

void Categoria1::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria1::GetPrioridad() const {
    return prioridad;
}
//0,10,412041,TORTILLAS DE MAIZ 1KG,15
void Categoria1::leer(ifstream &archProd){
    char c;
    
    archProd>>prioridad>>c>>minimo>>c;
    Producto::leer(archProd);   //412041,TORTILLAS DE MAIZ 1KG,15
}

void Categoria1::imprime(ofstream &archRep){
    Producto::imprime(archRep);
    archRep<<right<<setw(6)<<prioridad<<setw(10)<<minimo<<endl;
}

int Categoria1::GetPrioridad(){
    return prioridad;
}