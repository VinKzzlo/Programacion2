/* 
 * File:   NProductos.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:52 AM
 */

#ifndef NPRODUCTOS_H
#define NPRODUCTOS_H

#include "Producto.h"

class NProductos {
public:
    NProductos();
    NProductos(const NProductos& orig);
    virtual ~NProductos();
    void leeProducto(ifstream &);
    void imprimeProducto(ofstream &);
    void operator = (class NProductos);
    int GetCodigo();
    int GetPrioridad();
private:
    Producto *prod;
};

#endif /* NPRODUCTOS_H */

