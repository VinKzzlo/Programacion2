/* 
 * File:   Nodo.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:53 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Nodo.h"
#include "Pedido.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Lista;
private:
    Pedido *ped;
    Nodo *sig;
};

#endif /* NODO_H */

