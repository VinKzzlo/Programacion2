/* 
 * File:   Programa.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:55 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programa.h"
#include "NProductos.h"

Programa::Programa() {
}

Programa::Programa(const Programa& orig) {
}

Programa::~Programa() {
}

void Programa::carga(){
    cargaProductos();
    cargaLista();
}

void Programa::cargaProductos(){
    ifstream archProd("Productos4.csv",ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Productos4.csv"<<endl;
        exit(1);
    }
    int i=0;
    NProductos nprod;
    while(1){
        nprod.leeProducto(archProd);
        if(archProd.eof()) break;
        vproductos.push_back(nprod);
    }
}

void Programa::cargaLista(){
    ifstream archPed("Pedidos4.csv",ios::in);
    if(not archPed.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Pedidos4.csv"<<endl;
        exit(1);
    }
    lpedidos.llenarLista(archPed);
}

void Programa::muestra(){
    imprimeProductos();
    imprimePedidos();
}

void Programa::imprimeProductos(){
    ofstream archRep("ListaDeProductos.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo ListaDeProductos.txt"<<endl;
        exit(1);
    }
    for(int i=0;i<vproductos.size();i++){
        vproductos[i].imprimeProducto(archRep);
    }
}

void Programa::imprimePedidos(){
    ofstream archRep("ListaDePedidos.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo ListaDeProductos.txt"<<endl;
        exit(1);
    }
    lpedidos.imprimeLista(archRep);
}

void Programa::actualiza(){
    int codProd[200],prior[200],n;
    NProductos nprod;
    lpedidos.obtenerCodigos(codProd,n);
    for(int i=0;i<n;i++)
        for(int j=0;j<vproductos.size();j++)
            if(codProd[i]==vproductos[j].GetCodigo()){
                prior[i] = vproductos[j].GetPrioridad();
                break;
            }
    lpedidos.reordena(prior,n);
}