/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 14 de junio de 2024, 05:23 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programa.h"
int main(int argc, char** argv) {
    
    Programa programa;
    
    programa.carga();
    programa.muestra();
    programa.actualiza();
    programa.muestra();
    
    return 0;
}

