/* 
 * File:   NProductos.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:52 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "NProductos.h"
#include "Categoria1.h"
#include "Categoria2.h"
#include "Categoria3.h"

NProductos::NProductos() {
    prod = nullptr;
}

NProductos::NProductos(const NProductos& orig) {
    this->prod = orig.prod;
}

NProductos::~NProductos() {
}
/*
1,0,10,412041,TORTILLAS DE MAIZ 1KG,15
2,0,25,580927,TORTILLAS DE HARINA DEL HOGAR 22P. 840GR,6
3,1,40,459032,GELATINA DANY LIMON 125GR,24
*/
void NProductos::leeProducto(ifstream &archProd){
    int cat;
    
    archProd>>cat;
    if(archProd.eof()) return;
    archProd.get();
    switch(cat){
        case 1:
            prod = new Categoria1;
            break;
        case 2:
            prod = new Categoria2;
            break;
        case 3:
            prod = new Categoria3;
            break;
    }
    prod->leer(archProd);   //Polimorfismo
}

void NProductos::imprimeProducto(ofstream &archRep){
    prod->imprime(archRep);
}

int NProductos::GetCodigo(){
    return prod->GetCodprod();
}

int NProductos::GetPrioridad(){
    return prod->GetPrioridad();
}