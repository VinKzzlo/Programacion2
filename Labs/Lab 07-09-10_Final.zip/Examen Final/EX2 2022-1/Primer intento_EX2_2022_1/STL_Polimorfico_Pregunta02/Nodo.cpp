/* 
 * File:   Nodo.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:53 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    ped = nullptr;
    sig = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

