/* 
 * File:   Producto.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:47 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Producto.h"

Producto::Producto() {
    codprod = 0;
    nombre = nullptr;
    stock = 0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::GetCodprod() const {
    return codprod;
}

void Producto::SetNombre(char *cad){
    if(nombre) delete nombre;
    nombre = new char[strlen(cad)+1];
    strcpy(nombre,cad);
}
    
void Producto::GetNombre(char *cad) const{
    if(nombre) strcpy(cad,nombre);
    else cad[0] = '\0';
}
//412041,TORTILLAS DE MAIZ 1KG,15
void Producto::leer(ifstream &archProd){
    char nomb[60];
    
    archProd>>codprod;
    archProd.get();
    archProd.getline(nomb,60,',');
    SetNombre(nomb);
    archProd>>stock;
    archProd.get();
}

void Producto::imprime(ofstream &archRep){
    archRep<<left<<setw(8)<<codprod<<setw(40)<<nombre<<right<<setw(10)<<stock;
}