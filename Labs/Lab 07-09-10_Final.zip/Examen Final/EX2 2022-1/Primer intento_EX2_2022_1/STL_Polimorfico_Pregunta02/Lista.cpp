/* 
 * File:   Lista.cpp
 * Author: ramir
 * 
 * Created on 15 de junio de 2024, 10:53 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Lista.h"

Lista::Lista() {
    lini = nullptr;
    lfin = nullptr;
}

Lista::Lista(const Lista& orig) {
}

Lista::~Lista() {
}

void Lista::llenarLista(ifstream &archPed){
    int codigo;
    Nodo *nuevo;
    while(1){
        archPed>>codigo;
        if(archPed.eof()) break;
        archPed.get();
        nuevo = new Nodo;
        nuevo->ped = new Pedido;
        nuevo->ped->SetCodigo(codigo);
        nuevo->ped->leerDatos(archPed);
        insertar(nuevo);
    }
}
//Insertar ordenado en lista simplemente enlazada
void Lista::insertar(class Nodo *nuevo){
    Nodo *p = lini,*ant = nullptr;
    if(lini==nullptr){
        lini = nuevo;
        lfin = nuevo;
    }else{
        while(p){
            if(p->ped->GetFecha()>nuevo->ped->GetFecha()) break;
            ant = p;
            p = p->sig;
        }
        nuevo->sig = p;
        
        if(p==nullptr) lfin = nuevo;    //Si nuevo se inserta en lfin
        
        if(ant) ant->sig = nuevo;       //Si hay nodo anterior
        else lini = nuevo;              //Si nuevo se inserta en lini
    }
}

void Lista::imprimeLista(ofstream &archRep){
    Nodo *p = lini;
    while(p){
        p->ped->imprime(archRep);
        p = p->sig;
    }
}

void Lista::obtenerCodigos(int *codProd,int &n){
    Nodo *p = lini;
    n = 0;
    while(p){
        codProd[n] = p->ped->GetCodigo();
        p = p->sig;
        n++;
    }
}

void Lista::reordena(int *prior,int n){
    Nodo *p = lini->sig,*ant = lini;
    int i=1;
    while(p){
        if(prior[i]==1){
            p->ped->SetOrden(1);
            ant->sig = p->sig;
            p->sig = lini;
            lini = p;
            p = ant->sig;
            if(p==nullptr) lfin = ant;
        }else{
            p->ped->SetOrden(0);
            ant = p;
            p = p->sig;
        }
        i++;
    }
}