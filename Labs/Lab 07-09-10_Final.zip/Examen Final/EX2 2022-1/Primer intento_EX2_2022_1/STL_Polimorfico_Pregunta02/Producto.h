/* 
 * File:   Producto.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:47 AM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H

class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetStock(int stock);
    int GetStock() const;
    void SetCodprod(int codprod);
    int GetCodprod() const;
    void SetNombre(char *cad);
    void GetNombre(char *cad) const;
    virtual void leer(ifstream &);
    virtual void imprime(ofstream &);
    virtual int GetPrioridad()=0;
private:
    int codprod;
    char *nombre;
    int stock;
};

#endif /* PRODUCTO_H */

