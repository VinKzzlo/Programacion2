/* 
 * File:   Lista.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:53 AM
 */

#ifndef LISTA_H
#define LISTA_H

#include "Nodo.h"

class Lista {
public:
    Lista();
    Lista(const Lista& orig);
    virtual ~Lista();
    void llenarLista(ifstream &);
    void imprimeLista(ofstream &);
    void obtenerCodigos(int*,int&);
    void reordena(int*,int);
private:
    Nodo *lini;
    Nodo *lfin;
    void insertar(class Nodo*);
};

#endif /* LISTA_H */

