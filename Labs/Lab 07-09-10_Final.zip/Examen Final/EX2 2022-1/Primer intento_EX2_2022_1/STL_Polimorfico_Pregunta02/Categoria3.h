/* 
 * File:   Categoria3.h
 * Author: ramir
 *
 * Created on 15 de junio de 2024, 10:51 AM
 */

#ifndef CATEGORIA3_H
#define CATEGORIA3_H

#include "Producto.h"

class Categoria3:public Producto {
public:
    Categoria3();
    Categoria3(const Categoria3& orig);
    virtual ~Categoria3();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void leer(ifstream &);
    void imprime(ofstream &);
    int GetPrioridad();
private:
    int prioridad;
    double descuento;
};

#endif /* CATEGORIA3_H */

