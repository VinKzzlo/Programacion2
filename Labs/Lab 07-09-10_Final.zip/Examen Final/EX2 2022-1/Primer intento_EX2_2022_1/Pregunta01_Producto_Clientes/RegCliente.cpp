/* 
 * File:   RegCliente.cpp
 * Author: ramir
 * 
 * Created on 8 de junio de 2024, 04:05 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "RegCliente.h"

RegCliente::RegCliente() {
}

RegCliente::RegCliente(const RegCliente& orig) {
}

RegCliente::~RegCliente() {
}
/*
71984468,IPARRAGUIRRE VILLEGAS NICOLAS EDILBERTO B,935441620
29847168,ALDAVE ZEVALLOS ROSARIO A,6261108
*/
void RegCliente::leerDatosCliente(ifstream &archCli){
    cliente.leerDatos(archCli);
    switch(cliente.GetTipo()){
        case 'A':
            cliente.SetDescuento(23.5);
            break;
        case 'B':
            cliente.SetDescuento(16.8);
            break;
        case 'C':
            cliente.SetDescuento(8.3);
            break;
    }
}

void RegCliente::imprimeDatos(ofstream &archRep){
    cliente.imprimirDatos(archRep);
    for(list<class Pedido>::iterator 
            it = pedidos.begin();       it!=pedidos.end();  it++)
        (*it).imprimirDatos(archRep);
}