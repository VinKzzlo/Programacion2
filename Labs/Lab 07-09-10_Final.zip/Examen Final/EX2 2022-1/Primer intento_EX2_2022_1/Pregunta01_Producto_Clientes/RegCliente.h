/* 
 * File:   RegCliente.h
 * Author: ramir
 *
 * Created on 8 de junio de 2024, 04:05 PM
 */

#ifndef REGCLIENTE_H
#define REGCLIENTE_H

#include <list>

#include "Cliente.h"
#include "Pedido.h"

class RegCliente {
public:
    RegCliente();
    RegCliente(const RegCliente& orig);
    virtual ~RegCliente();
    void leerDatosCliente(ifstream &);
    void imprimeDatos(ofstream &);
private:
    Cliente cliente;
    list <class Pedido> pedidos;
};

#endif /* REGCLIENTE_H */

