/* 
 * File:   Empresa.h
 * Author: ramir
 *
 * Created on 8 de junio de 2024, 04:06 PM
 */

#ifndef EMPRESA_H
#define EMPRESA_H

#include <list>

class Empresa {
public:
    Empresa();
    Empresa(const Empresa& orig);
    virtual ~Empresa();
    void leerClientes(const char*);
    void imprimirClientes(const char*);
    void leerPedidos(const char*);
    void ordenarPedidos();
    void imprimirProductos(const char*);
private:
    list <class Producto> lstProductos;
    list <class RegCliente> lstClientes;
};

#endif /* EMPRESA_H */

