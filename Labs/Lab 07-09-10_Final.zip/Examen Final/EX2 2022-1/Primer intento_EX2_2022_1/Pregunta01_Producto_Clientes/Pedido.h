/* 
 * File:   Pedido.h
 * Author: ramir
 *
 * Created on 8 de junio de 2024, 04:02 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetSubTotal(double subTotal);
    double GetSubTotal() const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetCantidad(double cantidad);
    double GetCantidad() const;
    void SetCodigo(int codigo);
    int GetCodigo() const;
    void imprimirDatos(ofstream &);
private:
    int codigo;
    double cantidad;
    int fecha;
    double subTotal;
};

#endif /* PEDIDO_H */

