/* 
 * File:   Pedido.cpp
 * Author: ramir
 * 
 * Created on 8 de junio de 2024, 04:02 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    codigo = 0;
    cantidad = 0.0;
    fecha = 0;
    subTotal = 0.0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetSubTotal(double subTotal) {
    this->subTotal = subTotal;
}

double Pedido::GetSubTotal() const {
    return subTotal;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetCantidad(double cantidad) {
    this->cantidad = cantidad;
}

double Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::imprimirDatos(ofstream &archRep){
    archRep<<fixed<<setprecision(2);
    int dd = fecha%100;
    int mm = (fecha/100)%100;
    int aa = fecha/10000;
    archRep<<right<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)<<mm<<'/'
           <<setfill(' ')<<setw(4)<<aa<<setw(10)<<codigo<<setw(10)<<cantidad
           <<setw(10)<<subTotal<<endl;
}