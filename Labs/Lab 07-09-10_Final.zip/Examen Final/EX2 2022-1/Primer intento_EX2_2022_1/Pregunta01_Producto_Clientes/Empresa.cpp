/* 
 * File:   Empresa.cpp
 * Author: ramir
 * 
 * Created on 8 de junio de 2024, 04:06 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <iterator>
using namespace std;
#include "Empresa.h"
#include "RegCliente.h"

Empresa::Empresa() {
}

Empresa::Empresa(const Empresa& orig) {
}

Empresa::~Empresa() {
}

void Empresa::leerClientes(const char *nombArch){
    ifstream archCli(nombArch,ios::in);
    if(not archCli.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    RegCliente regCliente;
    while(1){
        regCliente.leerDatosCliente(archCli);
        if(archCli.eof()) break;
        lstClientes.push_back(regCliente);
    }
}

void Empresa::imprimirClientes(const char *nombArch){
    ofstream archRep(nombArch,ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    //             Inicio                    Condicion       Incremento
    for(list<class RegCliente>::iterator 
            it = lstClientes.begin();   it!=lstClientes.end();  it++){
        (*it).imprimeDatos(archRep);
    }
}

void Empresa::leerPedidos(const char *nombArch){
    
}

void Empresa::ordenarPedidos(){
    
}

void Empresa::imprimirProductos(const char *nombArch){
    
}