import java.util.ArrayList;
import java.util.Scanner;

public class PrimeraClase{
	private ArrayList<String> articulosSolicitados;
	
	public PrimeraClase(){
		articulosSolicitados = new ArrayList<String>();
	}
}