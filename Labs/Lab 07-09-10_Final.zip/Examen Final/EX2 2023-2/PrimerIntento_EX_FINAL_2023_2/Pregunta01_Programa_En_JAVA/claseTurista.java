import java.util.ArrayList;
import java.util.Scanner;

public class claseTurista{
	private boolean valija;
	private boolean almuerzo;
	private double tarifaExtra;
	
	public void setTarifaExtra(double tarifaExtra){this.tarifaExtra = tarifaExtra;}
	public double getTarifaExtra(){return tarifaExtra;}
}