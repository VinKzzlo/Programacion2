import java.util.ArrayList;
import java.util.Scanner;

public class Empresa{
	private ArrayList<String> flota;
	
	public Empresa(){
		flota = new ArrayList<String>();
	}
	
}