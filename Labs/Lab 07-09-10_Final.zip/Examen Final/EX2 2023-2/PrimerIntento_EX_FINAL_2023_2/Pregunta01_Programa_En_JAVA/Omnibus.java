import java.util.ArrayList;
import java.util.Scanner;

public class Omnibus{
	private String placa;
	private String chofer;
	private ArrayList<String> ruta;
	private int asientosPC;
	private int asientosCT;
	private ArrayList<Pasajero> pasajeros;
	
	public void setPlaca(String placa){this.placa = placa;}
	public String getPlaca(){return placa;}
	public void setChofer(String chofer){this.chofer = chofer;}
	public String getChofer(){return chofer;}
	public void setAsientosPC(int asientosPC){this.asientosPC = asientosPC;}
	public int getAsientosPC(){return asientosPC;}
	public void setAsientosCT(int asientosCT){this.asientosCT = asientosCT;}
	public String getAsientosCT(){return asientosCT;}
	
	public Omnibus(){
		ruta = new ArrayList<String>();
		pasajeros = new ArrayList<Pasajero>();
	}
	
}