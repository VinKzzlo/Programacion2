/* 
 * File:   Nodo.h
 * Author: ramir
 *
 * Created on 26 de junio de 2024, 12:04 AM
 */

#ifndef NODO_H
#define NODO_H

#include "Nodo.h"
#include "Vehiculo.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
private:
    Vehiculo *unidad;
    Nodo *izq;
    Nodo *der;
};

#endif /* NODO_H */

