/* 
 * File:   Programacion.h
 * Author: ramir
 *
 * Created on 26 de junio de 2024, 12:08 AM
 */

#ifndef PROGRAMACION_H
#define PROGRAMACION_H

#include "Arbol.h"
#include "Flota.h"

class Programacion {
public:
    Programacion();
    Programacion(const Programacion& orig);
    virtual ~Programacion();
    void cargavehiculos();
    void cargaprogramacion();
    void reducevehiculos(int);
    void muestraprogramacion();
private:
    Arbol ADespachos;
    Flota fVehiculos;
};

#endif /* PROGRAMACION_H */

