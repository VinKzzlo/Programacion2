/* 
 * File:   Nodo.cpp
 * Author: ramir
 * 
 * Created on 26 de junio de 2024, 12:04 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    izq = nullptr;
    der = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
    this->unidad = orig.unidad;
}

Nodo::~Nodo() {
    if(izq) delete izq;
    if(der) delete der;
}

