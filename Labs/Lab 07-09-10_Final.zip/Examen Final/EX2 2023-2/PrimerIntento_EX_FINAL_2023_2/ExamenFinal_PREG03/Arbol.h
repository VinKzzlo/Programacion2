/* 
 * File:   Arbol.h
 * Author: ramir
 *
 * Created on 26 de junio de 2024, 12:07 AM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"

class Arbol {
public:
    Arbol();
    Arbol(const Arbol& orig);
    virtual ~Arbol();
    void insertaVehiculo(class Vehiculo*);
    void reducirVehiculos(int);
    void imprimeArbol(ofstream &);
private:
    Nodo *raiz;
    void insertarR(class Nodo*&,class Nodo*);
    void eliminarNodos(class Nodo*&);
    void mostrarEnOrdenR(ofstream &,class Nodo*);
};

#endif /* ARBOL_H */

