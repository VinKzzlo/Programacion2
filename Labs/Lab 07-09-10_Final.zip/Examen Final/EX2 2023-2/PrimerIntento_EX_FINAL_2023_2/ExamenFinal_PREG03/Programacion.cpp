/* 
 * File:   Programacion.cpp
 * Author: ramir
 * 
 * Created on 26 de junio de 2024, 12:08 AM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programacion.h"

Programacion::Programacion() {
}

Programacion::Programacion(const Programacion& orig) {
}

Programacion::~Programacion() {
}

void Programacion::cargavehiculos(){
    fVehiculos.cargar_vehiculos();
    fVehiculos.cargar_pedidos();
}

void Programacion::cargaprogramacion(){
    fVehiculos.cargaVehiculosAArbol(ADespachos);
}

void Programacion::reducevehiculos(int cant){
    ADespachos.reducirVehiculos(cant);
}

void Programacion::muestraprogramacion(){
    ofstream archRep("Reporte.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    ADespachos.imprimeArbol(archRep);
}