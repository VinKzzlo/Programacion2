/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 25 de junio de 2024, 08:01 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Flota.h"
int main(int argc, char** argv) {
    
    Flota flota;
    
    flota.cargar_vehiculos();
    flota.cargar_pedidos();
    flota.mostrar_vehiculos();
    
    return 0;
}

