/* 
 * File:   Flota.h
 * Author: ramir
 *
 * Created on 25 de junio de 2024, 08:08 PM
 */

#ifndef FLOTA_H
#define FLOTA_H

#include <map>

#include "Vehiculo.h"

class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void cargar_vehiculos();
    void cargar_pedidos();
    void mostrar_vehiculos();
private:
    map<string,class Vehiculo*>vehiculos;
    void imprimirLinea(ofstream &,char);
};

#endif /* FLOTA_H */

