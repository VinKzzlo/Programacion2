/* 
 * File:   Pedido.cpp
 * Author: ramir
 * 
 * Created on 25 de junio de 2024, 08:02 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    cantidad = 0;
    peso = 0.0;
}

Pedido::Pedido(const Pedido& orig) {
    this->codigo = orig.codigo;
    this->cantidad = orig.cantidad;
    this->peso = orig.peso;
}

Pedido::~Pedido() {
}

void Pedido::SetPeso(double peso) {
    this->peso = peso;
}

double Pedido::GetPeso() const {
    return peso;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(string codigo) {
    this->codigo = codigo;
}

string Pedido::GetCodigo() const {
    return codigo;
}
//JXD.139,6,120
void Pedido::leerDatos(ifstream &archPed){
    char c;
    
    getline(archPed,codigo,',');
    archPed>>cantidad>>c>>peso;
    archPed.get();
}

void Pedido::mostrar(ofstream &archRep){
    archRep<<left<<setw(10)<<codigo<<setw(10)<<peso<<cantidad<<endl;
}