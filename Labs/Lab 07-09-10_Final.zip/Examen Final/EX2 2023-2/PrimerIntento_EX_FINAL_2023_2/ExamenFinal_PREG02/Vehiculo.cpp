/* 
 * File:   Vehiculo.cpp
 * Author: ramir
 * 
 * Created on 25 de junio de 2024, 08:02 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Vehiculo.h"

Vehiculo::Vehiculo() {
    dni = 0;
    carga_maxima = 0.0;
    carga_actual = 0.0;
}

Vehiculo::Vehiculo(const Vehiculo& orig) {
}

Vehiculo::~Vehiculo() {
}

void Vehiculo::SetCarga_actual(double carga_actual) {
    this->carga_actual = carga_actual;
}

double Vehiculo::GetCarga_actual() const {
    return carga_actual;
}

void Vehiculo::SetCarga_maxima(double carga_maxima) {
    this->carga_maxima = carga_maxima;
}

double Vehiculo::GetCarga_maxima() const {
    return carga_maxima;
}

void Vehiculo::SetPlaca(string placa) {
    this->placa = placa;
}

string Vehiculo::GetPlaca() const {
    return placa;
}

void Vehiculo::SetDni(int dni) {
    this->dni = dni;
}

int Vehiculo::GetDni() const {
    return dni;
}
//20864087,O5L-856,1000,
void Vehiculo::lee(ifstream &archVeh){
    archVeh>>dni;
    archVeh.get();
    getline(archVeh,placa,',');
    archVeh>>carga_maxima;
    archVeh.get();
}

void Vehiculo::mostrar(ofstream &archRep){
    archRep<<left<<setw(19)<<"Codigo de Cliente: "<<dni<<endl;
    archRep<<left<<setw(19)<<"Placa: "<<placa<<endl;
    archRep<<left<<setw(19)<<"Carga Maxima: "<<carga_maxima<<endl;
    archRep<<left<<setw(19)<<"Carga Actual: "<<carga_actual<<endl;
}