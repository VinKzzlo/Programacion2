/* 
 * File:   Camion.h
 * Author: ramir
 *
 * Created on 25 de junio de 2024, 08:05 PM
 */

#ifndef CAMION_H
#define CAMION_H

#include <vector>

#include "Vehiculo.h"
#include "Pedido.h"

class Camion:public Vehiculo {
public:
    Camion();
    Camion(const Camion& orig);
    virtual ~Camion();
    void SetLlantas(int llantas);
    int GetLlantas() const;
    void SetEjes(int ejes);
    int GetEjes() const;
    void lee(ifstream &);
    void mostrar(ofstream &);
    void insertar(class Pedido&);
private:
    int ejes;
    int llantas;
    vector<class Pedido>depositos;
    void imprimirLinea(ofstream &,char);
};

#endif /* CAMION_H */

