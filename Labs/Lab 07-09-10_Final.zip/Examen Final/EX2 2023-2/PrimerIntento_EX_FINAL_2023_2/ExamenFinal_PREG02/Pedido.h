/* 
 * File:   Pedido.h
 * Author: ramir
 *
 * Created on 25 de junio de 2024, 08:02 PM
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(string codigo);
    string GetCodigo() const;
    void leerDatos(ifstream &);
    void mostrar(ofstream &);
private:
    string codigo;
    int cantidad;
    double peso;
};

#endif /* PEDIDO_H */

