/* 
 * File:   Vehiculo.h
 * Author: ramir
 *
 * Created on 25 de junio de 2024, 08:02 PM
 */

#ifndef VEHICULO_H
#define VEHICULO_H

class Vehiculo {
public:
    Vehiculo();
    Vehiculo(const Vehiculo& orig);
    virtual ~Vehiculo();
    void SetCarga_actual(double carga_actual);
    double GetCarga_actual() const;
    void SetCarga_maxima(double carga_maxima);
    double GetCarga_maxima() const;
    void SetPlaca(string placa);
    string GetPlaca() const;
    void SetDni(int dni);
    int GetDni() const;
    virtual void lee(ifstream &);
    virtual void mostrar(ofstream &);
    virtual void insertar(class Pedido&)=0;
private:
    int dni;
    string placa;
    double carga_maxima;
    double carga_actual;
};

#endif /* VEHICULO_H */

