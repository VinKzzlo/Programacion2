/* 
 * File:   Furgon.cpp
 * Author: ramir
 * 
 * Created on 25 de junio de 2024, 08:06 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Furgon.h"
#define MAX_LINEA 60
Furgon::Furgon() {
    filas = 0;
    puertas = 0;
}

Furgon::Furgon(const Furgon& orig) {
}

Furgon::~Furgon() {
}

void Furgon::SetPuertas(int puertas) {
    this->puertas = puertas;
}

int Furgon::GetPuertas() const {
    return puertas;
}

void Furgon::SetFilas(int filas) {
    this->filas = filas;
}

int Furgon::GetFilas() const {
    return filas;
}
//79464412,K0D-676,300,1,3
void Furgon::lee(ifstream &archVeh){
    char c;
    
    Vehiculo::lee(archVeh); //79464412,K0D-676,300,
    archVeh>>filas>>c>>puertas;
    archVeh.get();
}

void Furgon::mostrar(ofstream &archRep){
    Vehiculo::mostrar(archRep);
    archRep<<left<<setw(19)<<"#Puertas:"<<puertas<<endl;
    archRep<<left<<setw(19)<<"#Filas:"<<filas<<endl;
    archRep<<"Lista de Pedidos:"<<endl;
    if(depositos.empty()){
        archRep<<"No hay pedidos para el cliente"<<endl;
    }else{
        for(list<class Pedido>::iterator
                it=depositos.begin();       it!=depositos.end();    it++){
            (*it).mostrar(archRep);
        }
    }
    imprimirLinea(archRep,'=');
}

void Furgon::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}

void Furgon::insertar(class Pedido &ped){
    
    if(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso() > GetCarga_maxima())
        return;
    
    list<class Pedido>::iterator it = depositos.begin();
    
    for(it;it!=depositos.end();it++)
        if((*it).GetPeso() > ped.GetPeso()) break;
    depositos.insert(it,ped);
    
    SetCarga_actual(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso());
}