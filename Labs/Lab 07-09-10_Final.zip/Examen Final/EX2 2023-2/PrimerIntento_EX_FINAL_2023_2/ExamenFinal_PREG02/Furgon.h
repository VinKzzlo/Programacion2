/* 
 * File:   Furgon.h
 * Author: ramir
 *
 * Created on 25 de junio de 2024, 08:06 PM
 */

#ifndef FURGON_H
#define FURGON_H

#include <list>

#include "Vehiculo.h"
#include "Pedido.h"

class Furgon:public Vehiculo {
public:
    Furgon();
    Furgon(const Furgon& orig);
    virtual ~Furgon();
    void SetPuertas(int puertas);
    int GetPuertas() const;
    void SetFilas(int filas);
    int GetFilas() const;
    void lee(ifstream &);
    void mostrar(ofstream &);
    void insertar(class Pedido&);
private:
    int filas;
    int puertas;
    list<class Pedido>depositos;
    void imprimirLinea(ofstream &,char);
};

#endif /* FURGON_H */

