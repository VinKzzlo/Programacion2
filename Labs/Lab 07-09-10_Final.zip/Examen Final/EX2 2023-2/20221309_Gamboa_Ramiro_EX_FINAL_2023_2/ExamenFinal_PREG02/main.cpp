/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 8 de julio de 2024, 04:15 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Flota.h"
int main(int argc, char** argv) {
    
    Flota flota;
    
    flota.cargar_vehiculos();
    flota.cargar_pedidos();
    flota.mostrar_vehiculos();
    
    return 0;
}

