/* 
 * File:   Camion.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 04:17 PM
 */

#ifndef CAMION_H
#define CAMION_H

#include <vector>

#include "Vehiculo.h"
#include "Pedido.h"

class Camion:public Vehiculo {
public:
    Camion();
    Camion(const Camion& orig);
    virtual ~Camion();
    void SetLlantas(int llantas);
    int GetLlantas() const;
    void SetEjes(int ejes);
    int GetEjes() const;
    void lee(ifstream &);
    void insertar(class Pedido &);
    void mostrar(ofstream &);
private:
    int ejes;
    int llantas;
    vector<class Pedido>depositos;
    void imprimirLinea(ofstream &,char);
};

#endif /* CAMION_H */

