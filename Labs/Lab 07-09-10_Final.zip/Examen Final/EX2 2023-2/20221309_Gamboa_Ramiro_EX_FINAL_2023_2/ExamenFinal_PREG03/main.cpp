/* 
 * File:   main.cpp
 * Author: R4
 *
 * Created on 8 de julio de 2024, 10:02 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programacion.h"
int main(int argc, char** argv) {
    
    Programacion pro;
    
    pro.cargavehiculos();
    pro.cargaprogramacion();
    pro.reducevehiculos(10);
    pro.muestraprogramacion();
    
    return 0;
}

