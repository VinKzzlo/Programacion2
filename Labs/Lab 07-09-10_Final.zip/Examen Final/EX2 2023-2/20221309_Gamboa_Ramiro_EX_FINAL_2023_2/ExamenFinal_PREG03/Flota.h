/* 
 * File:   Flota.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 04:19 PM
 */

#ifndef FLOTA_H
#define FLOTA_H

#include <map>

#include "Vehiculo.h"

class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void cargar_vehiculos();
    void cargar_pedidos();
    void mostrar_vehiculos();
    void cargaVehiculosAArbol(class Arbol &);
private:
    map<string,class Vehiculo*>vehiculos;
    void imprimirLinea(ofstream &,char);
};

#endif /* FLOTA_H */

