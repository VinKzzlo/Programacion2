/* 
 * File:   Arbol.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 10:04 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Arbol.h"

Arbol::Arbol() {
    raiz = nullptr;
}

Arbol::Arbol(const Arbol& orig) {
}

Arbol::~Arbol() {
}

void Arbol::insertarVehiculo(class Vehiculo *pveh){
    Nodo *nuevo = new Nodo;
    nuevo->unidad = pveh;
    insertarR(raiz,nuevo);
}

void Arbol::insertarR(class Nodo *&arbol,class Nodo *nuevo){
    if(arbol==nullptr){
        arbol = nuevo;
    }else{
        if(arbol->unidad->GetDni()>nuevo->unidad->GetDni()){
            insertarR(arbol->izq,nuevo);
        }else{
            insertarR(arbol->der,nuevo);
        }
    }
}

void Arbol::reducirVehiculos(int cantidad){
    for(int i=0;i<cantidad;i++)
        eliminarNodos(raiz);
}

void Arbol::eliminarNodos(class Nodo *&arbol){
    
    if(arbol==nullptr) return;
    if(arbol->izq==nullptr and arbol->der==nullptr){
        delete arbol;
        arbol = nullptr;
        return;
    }
    
    if(arbol->izq){
        eliminarNodos(arbol->izq);
    }else{
        eliminarNodos(arbol->der);
    }
}

void Arbol::imprimeArbol(ofstream &archRep){
    mostrarEnOrdenR(archRep,raiz);
}

void Arbol::mostrarEnOrdenR(ofstream &archRep,class Nodo *arbol){
    
    if(arbol==nullptr) return;
    
    mostrarEnOrdenR(archRep,arbol->izq);
    arbol->unidad->mostrar(archRep);
    mostrarEnOrdenR(archRep,arbol->der);
}