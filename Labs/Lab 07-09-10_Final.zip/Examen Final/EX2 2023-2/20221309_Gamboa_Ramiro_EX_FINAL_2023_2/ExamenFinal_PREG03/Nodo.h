/* 
 * File:   Nodo.h
 * Author: ramir
 *
 * Created on 8 de julio de 2024, 10:03 PM
 */

#ifndef NODO_H
#define NODO_H

#include "Nodo.h"
#include "Vehiculo.h"

class Nodo {
public:
    Nodo();
    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
private:
    Vehiculo *unidad;
    Nodo *izq;
    Nodo *der;
};

#endif /* NODO_H */

