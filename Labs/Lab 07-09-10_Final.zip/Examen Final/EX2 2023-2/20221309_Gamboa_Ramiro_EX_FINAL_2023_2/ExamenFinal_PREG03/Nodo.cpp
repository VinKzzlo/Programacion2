/* 
 * File:   Nodo.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 10:03 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    unidad = nullptr;
    izq = nullptr;
    der = nullptr;
}

Nodo::Nodo(const Nodo& orig) {
}

Nodo::~Nodo() {
}

