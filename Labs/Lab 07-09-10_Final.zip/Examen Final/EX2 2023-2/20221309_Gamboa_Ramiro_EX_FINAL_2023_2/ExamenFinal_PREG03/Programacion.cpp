/* 
 * File:   Programacion.cpp
 * Author: ramir
 * 
 * Created on 8 de julio de 2024, 10:05 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Programacion.h"

Programacion::Programacion() {
}

Programacion::Programacion(const Programacion& orig) {
}

Programacion::~Programacion() {
}

void Programacion::cargavehiculos(){
    fVehiculos.cargar_vehiculos();
    fVehiculos.cargar_pedidos();
}

void Programacion::cargaprogramacion(){
    fVehiculos.cargaVehiculosAArbol(ADespachos);
}

void Programacion::reducevehiculos(int cantidad){
    ADespachos.reducirVehiculos(cantidad);
}

void Programacion::muestraprogramacion(){
    ofstream archRep("Reporte.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    ADespachos.imprimeArbol(archRep);
}