import java.util.ArrayList;
import java.util.Scanner;

public class Omnibus{
	private String placa;
	private String chofer;
	private ArrayList<String> ruta;
	private int asientosPC;
	private int asientosCT;
	private ArrayList<Pasajero> pasajeros;
	
	public void setPlaca(String placa){this.placa = placa;}
	public String getPlaca(){return placa;}
	public void setChofer(String chofer){this.chofer = chofer;}
	public String getChofer(){return chofer;}
	public void setAsientosPC(int asientosPC){this.asientosPC = asientosPC;}
	public int getAsientosPC(){return asientosPC;}
	public void setAsientosCT(int asientosCT){this.asientosCT = asientosCT;}
	public int getAsientosCT(){return asientosCT;}
	
	public Omnibus(){
		ruta = new ArrayList<String>();
		pasajeros = new ArrayList<Pasajero>();
	}
	
	public boolean lee(Scanner arch){
		String ciudad;
		
		placa = arch.next();
		if(placa.compareTo("FIN")==0) return false;
		chofer = arch.next();
		while(!arch.hasNextInt()){
			ciudad = arch.next();
			ruta.add(ciudad);
		}
		asientosPC = arch.nextInt();
		asientosCT = arch.nextInt();
		return true;
	}
	
	public boolean sePuedeUbicar(Pasajero pasajero){
		String tipo,destino;
		
		destino = pasajero.getDestino();
		tipo = pasajero.getTipo();
		if(pasaPor(destino)){
			if(tipo.compareTo("P")==0 && asientosPC>0){
				pasajeros.add(pasajero);
				asientosPC--;
				return true;
			}
			if(tipo.compareTo("T")==0 && asientosCT>0){
				pasajeros.add(pasajero);
				asientosCT--;
				return true;
			}
		}
		return false;
	}
	
	public boolean pasaPor(String destino){
		for(String ciudad: ruta){
			if(ciudad.compareTo(destino)==0) return true;
		}
		return false;
	}
	
	public void imprimeDatos(){
		int indice;
		System.out.println("PLACA:  "+placa);
		System.out.println("CHOFER: "+chofer);
		System.out.println("ASIENTOS LIBRES PC: "+asientosPC);
		System.out.println("ASIENTOS LIBRES CT: "+asientosCT);
		System.out.println("RUTA:");
		for(String ciudad: ruta)
			System.out.print(" "+ciudad);
		System.out.println(" ");
		System.out.println("PASAJEROS:");
		for(int i=0;i<pasajeros.size();i++){
			indice = i+1;
			System.out.print(" "+indice+") ");
			pasajeros.get(i).imprimeDatos();
		}
	}
}