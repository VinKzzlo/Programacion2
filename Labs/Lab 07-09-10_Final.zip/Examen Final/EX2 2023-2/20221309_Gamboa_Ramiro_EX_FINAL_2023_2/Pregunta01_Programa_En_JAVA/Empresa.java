import java.util.ArrayList;
import java.util.Scanner;

public class Empresa{
	private ArrayList<Omnibus> flota;
	
	public Empresa(){
		flota = new ArrayList<Omnibus>();
	}
	
	public void leerOmnibus(Scanner arch){
		Omnibus omnibus;
		while(arch.hasNext()){
			omnibus = new Omnibus();
			if(!omnibus.lee(arch)) break;
			flota.add(omnibus);
		}
	}
	
	public void leerPasajeros(Scanner arch){
		String tipo;
		Pasajero pasajero;
		while(arch.hasNext()){
			tipo = arch.next();
			if(tipo.compareTo("P")==0) pasajero = new PrimeraClase();
			else pasajero = new claseTurista();
			pasajero.leerDatos(arch);
			for(Omnibus omnibus:flota){
				if(omnibus.sePuedeUbicar(pasajero)) break;
			}
		}
	}
	
	public void mostrarReporte(){
		System.out.println("EMPRESA DE TRANSPORTE TURISTICO");
		for(Omnibus omnibus: flota){
			omnibus.imprimeDatos();
		}
	}
}