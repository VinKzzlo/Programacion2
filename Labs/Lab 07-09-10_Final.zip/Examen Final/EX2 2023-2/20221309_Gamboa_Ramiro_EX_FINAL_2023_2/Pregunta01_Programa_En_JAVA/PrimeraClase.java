import java.util.ArrayList;
import java.util.Scanner;

public class PrimeraClase extends Pasajero{
	private ArrayList<String> articulosSolicitados;
	
	public PrimeraClase(){
		articulosSolicitados = new ArrayList<String>();
	}
	
	@Override
	public String getTipo(){
		return "P";
	}
	
	@Override
	public void leerDatos(Scanner arch){
		int numArticulos;
		String articulo;
		
		super.leerDatos(arch);
		numArticulos = arch.nextInt();
		for(int i=0;i<numArticulos;i++){
			articulo = arch.next();
			articulosSolicitados.add(articulo);
		}
	}
	
	@Override
	public void imprimeDatos(){
		super.imprimeDatos();
		System.out.print("      \"PRIMERA CLASE\"  EXTRAS: ");
		for(String articulo: articulosSolicitados)
			System.out.print(articulo+" ");
		System.out.println();
	}
}