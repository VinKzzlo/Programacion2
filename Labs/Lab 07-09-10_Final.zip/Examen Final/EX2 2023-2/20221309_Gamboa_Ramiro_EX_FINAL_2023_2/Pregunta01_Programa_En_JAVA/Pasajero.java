import java.util.ArrayList;
import java.util.Scanner;

public abstract class Pasajero{
	private int dni;
	private String nombre;
	private String destino;
	
	public void setDni(int dni){this.dni = dni;}
	public int getDni(){return dni;}
	public void setNombre(String nombre){this.nombre = nombre;}
	public String getNombre(){return nombre;}
	public void setDestino(String destino){this.destino = destino;}
	public String getDestino(){return destino;}
	
	public abstract String getTipo();
	
	public void leerDatos(Scanner arch){
		dni = arch.nextInt();
		nombre = arch.next();
		destino = arch.next();
	}
	
	public void imprimeDatos(){
		System.out.printf("DNI: %d NOMBRE: %s Destino: %s\n",dni,nombre,destino);
	}
}