import java.util.ArrayList;
import java.util.Scanner;

public class claseTurista extends Pasajero{
	private boolean valija;
	private boolean almuerzo;
	double tarifaExtra;
	
	public void setValija(boolean valija){this.valija = valija;}
	public boolean getValija(){return valija;}
	public void setAlmuerzo(boolean almuerzo){this.almuerzo = almuerzo;}
	public boolean getAlmuerzo(){return almuerzo;}
	public void setTarifaExtra(double tarifaExtra){this.tarifaExtra = tarifaExtra;}
	public double getTarifaExtra(){return tarifaExtra;}
	
	public claseTurista(){
		valija = false;
		almuerzo = false;
		tarifaExtra = 0.0;
	}
	
	@Override
	public String getTipo(){
		return "T";
	}
	
	@Override
	public void leerDatos(Scanner arch){
		String SN;
		
		super.leerDatos(arch);
		SN = arch.next();
		if(SN.compareTo("S")==0){
			valija = true;
			tarifaExtra += 85.5;
		}
		SN = arch.next();
		if(SN.compareTo("S")==0){
			almuerzo = true;
			tarifaExtra += 55.9;
		}
	}
	
	@Override
	public void imprimeDatos(){
		super.imprimeDatos();
		System.out.print("      \"CLASE TURISTA\"  EXTRAS: ");
		if(valija) System.out.print(" VALIJA");
		if(almuerzo) System.out.print(" ALMUERZO");
		System.out.println("  - TARIFA EXTRA: "+tarifaExtra);
	}
}