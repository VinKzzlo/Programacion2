import java.util.ArrayList;
import java.util.Scanner;

public class Omnibus {
	private String placa;
	private String chofer;
	private ArrayList<String> ciudades;
	private int asientosPC;
	private int asientosCT;
	private ArrayList<Pasajero> pasajeros;
	
	Omnibus() {
		ciudades = new ArrayList<String>();
		pasajeros = new ArrayList<Pasajero>();
	}
	
	public void setPlaca(String placa) { this.placa = placa; }
	public int getAsientosPC() { return asientosPC; }
	public void setAsientosPC(int asientosPC) { this.asientosPC = asientosPC; }
	public int getAsientosCT() { return asientosCT; }
	public void setAsientosCT(int asientosCT) { this.asientosCT = asientosCT; }
	
	public void leer(Scanner arch) {
		chofer = arch.next();
		
		while (!arch.hasNextInt()) {
			String ciudadLeida;
			ciudadLeida = arch.next();
			ciudades.add(ciudadLeida);
		}
		
		asientosPC = arch.nextInt();
		asientosCT = arch.nextInt();
	}
	
	public boolean tieneDestino(String destinoDeseado) {
		for (int i = 0; i != ciudades.size(); ++i)
			if (ciudades.get(i).compareTo(destinoDeseado) == 0) return true;
		
		return false;
	}
	
	public void asignarPasajero(Pasajero pasajero, String categoria) {
		if (categoria.compareTo("P") == 0) --asientosPC;
		else --asientosCT;
		
		pasajeros.add(pasajero);
	}
	
	public void imprimir() {
		System.out.print("Placa:       ");
		System.out.print("Chofer:      ");
		System.out.print("Asientos PC: ");
		System.out.print("Asientos CT: ");
		
		System.out.println("Ciudades:");
		for (int i = 0; i != ciudades.size(); ++i)
			System.out.println(" - " + ciudades.get(i));
		
		System.out.println("Pasajeros:");
		for (int i = 0; i != pasajeros.size(); ++i)
			pasajeros.get(i).imprimir();
	}
}