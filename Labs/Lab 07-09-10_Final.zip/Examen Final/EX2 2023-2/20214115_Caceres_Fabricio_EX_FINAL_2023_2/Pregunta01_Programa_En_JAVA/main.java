import java.util.ArrayList;
import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Empresa empresa = new Empresa();
		Scanner arch = new Scanner(System.in);
		
		empresa.leerBuses(arch);
		empresa.leerPasajeros(arch);
		empresa.emitirReporte();
	}
}