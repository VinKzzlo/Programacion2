import java.util.ArrayList;
import java.util.Scanner;

public class PrimeraClase extends Pasajero {
	ArrayList<String> articulosSolicitados;
	
	PrimeraClase() { articulosSolicitados = new ArrayList<String>(); }
	
	public void leer(Scanner arch) {
		super.leer(arch);
		
		int cantidadArticulos = arch.nextInt();
		
		for (int i = 0; i != cantidadArticulos; ++i) {
			String articuloActual = arch.next();
			articulosSolicitados.add(articuloActual);
		}
	}
	
	public boolean puedeTomarBus(Omnibus bus) {
		if (bus.getAsientosPC() == 0) return false;
		return bus.tieneDestino(super.getDestino());
	}
	
	public void imprimir() {
		super.imprimir();
		
		System.out.print(" de primera clase con articulos solicitados: ");
		for (int i = 0; i != articulosSolicitados.size(); ++i) {
			System.out.print(articulosSolicitados.get(i) + "  ");
		}
		System.out.println();
	}
}