import java.util.ArrayList;
import java.util.Scanner;

abstract public class Pasajero {
	private int dni;
	private String nombre;
	private String detino;
	
	public void leer(Scanner arch) {
		dni = arch.nextInt();
		nombre = arch.next();
		detino = arch.next();
	}
	
	abstract public boolean puedeTomarBus(Omnibus bus);
	
	public void imprimir() {
		System.out.print(dni + " - " + nombre + " con destino a " + detino);
	}
	
	public String getDestino() { return detino; }
}