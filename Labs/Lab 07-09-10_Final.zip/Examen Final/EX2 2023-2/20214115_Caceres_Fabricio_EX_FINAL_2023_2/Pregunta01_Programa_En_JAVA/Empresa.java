import java.util.ArrayList;
import java.util.Scanner;

public class Empresa {
	Empresa() { flota = new ArrayList<Omnibus>(); }
	
	private ArrayList<Omnibus> flota;
	
	public void leerBuses(Scanner arch) {
		String placa;
		
		while (true) {
			placa = arch.next();
			if (placa.compareTo("FIN") == 0) break;
			
			Omnibus bus = new Omnibus();
			bus.setPlaca(placa);
			bus.leer(arch);
			
			flota.add(bus);
		}
	}
	
	public void leerPasajeros(Scanner arch) {
		String categoria;
		
		while (arch.hasNext()) {
			categoria = arch.next();
			
			Pasajero pasajeroLeido;
			
			if (categoria.compareTo("P") == 0)
				pasajeroLeido = new PrimeraClase();
			else pasajeroLeido = new claseTurista();
			
			pasajeroLeido.leer(arch);
			
			asignarPasajero(pasajeroLeido, categoria);
		}
	}
	
	private void asignarPasajero(Pasajero pasajero, String categoria) {
		for (int i = 0; i != flota.size(); ++i) {
			if (!pasajero.puedeTomarBus(flota.get(i))) continue;
			flota.get(i).asignarPasajero(pasajero, categoria);
			break;
		}
	}
	
	public void emitirReporte() {
		for (int i = 0; i != flota.size(); ++i) {
			flota.get(i).imprimir();
			System.out.println("----------------------------");
		}
	}
}