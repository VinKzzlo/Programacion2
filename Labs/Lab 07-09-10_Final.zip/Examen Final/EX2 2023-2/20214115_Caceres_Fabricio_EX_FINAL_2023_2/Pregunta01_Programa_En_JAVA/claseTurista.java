import java.util.ArrayList;
import java.util.Scanner;

public class claseTurista extends Pasajero {
	boolean valija;
	boolean almuerzo;
	double tarifaExtra;
	
	public void leer(Scanner arch) {
		super.leer(arch);
		
		String deseaValija    = arch.next();
		String deseaAlimentos = arch.next();
		
		valija = (deseaValija.compareTo("S") == 0);
		almuerzo = (deseaAlimentos.compareTo("S") == 0);
	}
	
	public boolean puedeTomarBus(Omnibus bus) {
		if (bus.getAsientosCT() == 0) return false;
		return bus.tieneDestino(super.getDestino());
	}
	
	public void imprimir() {
		super.imprimir();
		
		System.out.print(" de clase turista ");
		if (valija) System.out.print("con valija");
		else System.out.print("sin valija");
		
		if (almuerzo) System.out.println("con almuerzo");
		else System.out.println("sin almuerzo");
	}
}