/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 08:07 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include <cstring>
#include "Flota.h"
#include "Furgon.h"
#include "Camion.h"
#define MAX_LINEA 40
#define RPAD(cad, n) right << setw(n) << cad
#define LPAD(cad, n) left  << setw(n) << cad
#define CPAD(cad, n) right << setw(n/2 + strlen(cad)/2) << cad
#define LINE(c,   n) setfill(c) << setw(n) << c << setfill(' ')

Flota::~Flota() {
    for (const auto& vehiculoActual : vehiculos)
        delete vehiculoActual.second;
}

void Flota::cargar_vehiculos() {
    ifstream arch("Vehiculos.csv", ios::in);
    verificarArchivo(arch, "Vehiculos.csv");
    
    Vehiculo* vehiculoLeido;
    char categoria;
    
    while (true) {
        arch >> categoria;
        if (arch.eof()) break;
        arch.get();
        
        if      (categoria == 'F') vehiculoLeido = new Furgon();
        else if (categoria == 'C') vehiculoLeido = new Camion();
        
        vehiculoLeido->leer(arch);
        vehiculos[vehiculoLeido->GetPlaca()] = vehiculoLeido;
    }
}

void Flota::cargar_pedidos() {
    ifstream arch("Pedidos4.csv", ios::in);
    verificarArchivo(arch, "Pedidos4.csv");
    
    Pedido pedidoLeido;
    string placaLeida;
    
    while (true) {
        getline(arch, placaLeida, ',');
        if (arch.eof()) break;
        
        pedidoLeido.leer(arch);
        
        vehiculos[placaLeida]->insertar(pedidoLeido);
    }
}

void Flota::mostrar_vehiculos() const {
    ofstream arch("Reporte.txt", ios::out);
    verificarArchivo(arch, "Reporte.txt");
    arch << setprecision(2) << fixed;
    
    arch << CPAD("REPORTE DE FLOTA", MAX_LINEA) << endl
         << LINE('=', MAX_LINEA) << endl;
    
//    for (const auto& vehiculoActual : vehiculos)
//        vehiculoActual.second->mostrar(arch);
    
    vehiculos.at(string("A1Q-612"))->mostrar(arch);
    vehiculos.at(string("D9A-711"))->mostrar(arch);
    vehiculos.at(string("O8J-848"))->mostrar(arch);
    vehiculos.at(string("Q5S-871"))->mostrar(arch);
    vehiculos.at(string("Z4L-514"))->mostrar(arch);
}

void Flota::verificarArchivo(const ifstream& arch, const char* nombreArch) const {
    if (arch.is_open()) return;
    
    cout << "Error abriendo " << nombreArch << endl;
    exit(1);
}

void Flota::verificarArchivo(const ofstream& arch, const char* nombreArch) const {
    if (arch.is_open()) return;
    
    cout << "Error abriendo " << nombreArch << endl;
    exit(1);
}