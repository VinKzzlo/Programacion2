/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 08:03 AM
 */

#include <iomanip>
using namespace std;
#include "Vehiculo.h"
#define RPAD(cad, n) right << setw(n) << cad
#define LPAD(cad, n) left  << setw(n) << cad
#define CPAD(cad, n) right << setw(n/2 + strlen(cad)/2) << cad
#define LINE(c,   n) setfill(c) << setw(n) << c << setfill(' ')

Vehiculo::Vehiculo()
        : carga_actual() {
}

void Vehiculo::leer(ifstream& arch) {
    char coma;
    
    arch >> dni >> coma;
    getline(arch, placa, ',');
    arch >> carga_maxima >> coma;
}

void Vehiculo::mostrar(ofstream& arch) const {
    arch << LPAD("Codigo de Cliente:", 22) << dni << endl
         << LPAD("Placa:", 22) << placa << endl
         << LPAD("Carga Maxima:", 22) << carga_maxima << endl
         << LPAD("Carga Actual:", 22) << carga_actual << endl;
}

void Vehiculo::SetCarga_actual(double carga_actual) {
    this->carga_actual = carga_actual;
}

double Vehiculo::GetCarga_actual() const {
    return carga_actual;
}

void Vehiculo::SetCarga_maxima(double carga_maxima) {
    this->carga_maxima = carga_maxima;
}

double Vehiculo::GetCarga_maxima() const {
    return carga_maxima;
}

void Vehiculo::SetPlaca(string placa) {
    this->placa = placa;
}

string Vehiculo::GetPlaca() const {
    return placa;
}

void Vehiculo::SetDni(int dni) {
    this->dni = dni;
}

int Vehiculo::GetDni() const {
    return dni;
}

