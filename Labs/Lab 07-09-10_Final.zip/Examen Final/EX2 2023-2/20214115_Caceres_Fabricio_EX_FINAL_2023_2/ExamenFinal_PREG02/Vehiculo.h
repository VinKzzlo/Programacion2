/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 08:03 AM
 */

#ifndef VEHICULO_H
#define VEHICULO_H
#include <string>
#include <fstream>

#include "Pedido.h"
using namespace std;

class Vehiculo {
public:
    Vehiculo();
    
    virtual void leer(ifstream& arch);
    virtual void insertar(const Pedido& pedido) = 0;
    virtual void mostrar(ofstream& arch) const;
    
    void SetCarga_actual(double carga_actual);
    double GetCarga_actual() const;
    void SetCarga_maxima(double carga_maxima);
    double GetCarga_maxima() const;
    void SetPlaca(string placa);
    string GetPlaca() const;
    void SetDni(int dni);
    int GetDni() const;
private:
    int dni;
    string placa;
    double carga_maxima;
    double carga_actual;
};

#endif /* VEHICULO_H */

