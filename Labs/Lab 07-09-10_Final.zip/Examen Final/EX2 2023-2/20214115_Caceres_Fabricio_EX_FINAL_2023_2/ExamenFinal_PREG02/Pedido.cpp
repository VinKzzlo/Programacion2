/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 07:59 AM
 */

#include <iomanip>
using namespace std;
#include "Pedido.h"
#define RPAD(cad, n) right << setw(n) << cad
#define LPAD(cad, n) left  << setw(n) << cad
#define CPAD(cad, n) right << setw(n/2 + strlen(cad)/2) << cad
#define LINE(c,   n) setfill(c) << setw(n) << c << setfill(' ')

void Pedido::leer(ifstream& arch) {
    char coma;
    
    getline(arch, codigo, ',');
    arch >> cantidad >> coma >> peso;
    arch.get();
}

void Pedido::mostrar(ofstream& arch) const {
    arch << LPAD(codigo, 10) << RPAD(peso, 8) << RPAD(cantidad, 5) << endl;
}

void Pedido::SetPeso(double peso) {
    this->peso = peso;
}

double Pedido::GetPeso() const {
    return peso;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(string codigo) {
    this->codigo = codigo;
}

string Pedido::GetCodigo() const {
    return codigo;
}

