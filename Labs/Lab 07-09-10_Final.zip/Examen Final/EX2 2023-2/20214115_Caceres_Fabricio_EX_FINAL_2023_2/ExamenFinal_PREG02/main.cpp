/* 
 * File:   main.cpp
 * Author: Fabricio Favian Cáceres Lecaros
 * Código: 20214115
 *
 * Created on 5 de diciembre de 2023, 07:59 AM
 */

#include "Utils.hpp"
#include "Flota.h"

int main(int argc, char** argv) {
    Flota flota;
    
    flota.cargar_vehiculos();
    flota.cargar_pedidos();
    flota.mostrar_vehiculos();
    
    return 0;
}