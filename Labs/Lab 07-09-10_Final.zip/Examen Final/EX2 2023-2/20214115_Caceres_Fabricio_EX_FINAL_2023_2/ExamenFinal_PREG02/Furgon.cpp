/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 08:06 AM
 */

#include <iomanip>
using namespace std;
#include "Furgon.h"
#define MAX_LINEA 40
#define RPAD(cad, n) right << setw(n) << cad
#define LPAD(cad, n) left  << setw(n) << cad
#define CPAD(cad, n) right << setw(n/2 + strlen(cad)/2) << cad
#define LINE(c,   n) setfill(c) << setw(n) << c << setfill(' ')

void Furgon::leer(ifstream& arch) {
    Vehiculo::leer(arch);
    
    char coma;
    arch >> filas >> coma >> puertas;
}

void Furgon::insertar(const Pedido& pedido) {
    if (GetCarga_actual() + pedido.GetCantidad()*pedido.GetPeso() >
        GetCarga_maxima()) return;
    
    double pesoPedido = pedido.GetPeso();
    list<Pedido>::iterator it = depositos.begin();
    
    for (it; it != depositos.end(); ++it)
        if (it->GetPeso() > pesoPedido) break;
    
    depositos.insert(it, pedido);
    SetCarga_actual(pedido.GetCantidad()*pedido.GetPeso() +
                    GetCarga_actual());
}

void Furgon::mostrar(ofstream& arch) const {
    Vehiculo::mostrar(arch);
    
    arch << LPAD("#Puertas:", 22) << puertas << endl
         << LPAD("#Filas:", 22) << filas << endl
         << "Lista de Pedidos:" << endl;
    if (depositos.empty()) arch << "No hay pedidos para el cliente" << endl;
    else for (const Pedido& pedidoActual : depositos)
        pedidoActual.mostrar(arch);
    
    arch << LINE('=', MAX_LINEA) << endl;
}

void Furgon::SetPuertas(int puertas) {
    this->puertas = puertas;
}

int Furgon::GetPuertas() const {
    return puertas;
}

void Furgon::SetFilas(int filas) {
    this->filas = filas;
}

int Furgon::GetFilas() const {
    return filas;
}

