/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 07:59 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <string>
#include <fstream>
using namespace std;

class Pedido {
public:
    void leer(ifstream& arch);
    void mostrar(ofstream& arch) const;
    
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(string codigo);
    string GetCodigo() const;
private:
    string codigo;
    int cantidad;
    double peso;
};

#endif /* PEDIDO_H */

