/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Camion.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 08:05 AM
 */

#include <iomanip>
using namespace std;
#include "Camion.h"
#define MAX_LINEA 40
#define RPAD(cad, n) right << setw(n) << cad
#define LPAD(cad, n) left  << setw(n) << cad
#define CPAD(cad, n) right << setw(n/2 + strlen(cad)/2) << cad
#define LINE(c,   n) setfill(c) << setw(n) << c << setfill(' ')

void Camion::leer(ifstream& arch) {
    Vehiculo::leer(arch);
    
    char coma;
    arch >> ejes >> coma >> llantas;
}

void Camion::insertar(const Pedido& pedido) {
    if (depositos.size() == 5) return;
    if (GetCarga_actual() + pedido.GetCantidad()*pedido.GetPeso() >
        GetCarga_maxima()) return;
    
    depositos.push_back(pedido);
    SetCarga_actual(pedido.GetCantidad()*pedido.GetPeso() +
                    GetCarga_actual());
}

void Camion::mostrar(ofstream& arch) const {
    Vehiculo::mostrar(arch);
    
    arch << LPAD("#Llantas:", 22) << llantas << endl
         << LPAD("#Ejes:", 22) << ejes << endl
         << "Lista de Pedidos:" << endl;
    
    if (depositos.empty()) arch << "No hay pedidos para el cliente" << endl;
    else for (const Pedido& pedidoActual : depositos)
            pedidoActual.mostrar(arch);
    
    arch << LINE('=', MAX_LINEA) << endl;
}

void Camion::SetLlantas(int llantas) {
    this->llantas = llantas;
}

int Camion::GetLlantas() const {
    return llantas;
}

void Camion::SetEjes(int ejes) {
    this->ejes = ejes;
}

int Camion::GetEjes() const {
    return ejes;
}

