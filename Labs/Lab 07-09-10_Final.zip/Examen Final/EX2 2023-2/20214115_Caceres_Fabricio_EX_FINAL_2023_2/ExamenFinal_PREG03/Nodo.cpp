/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 09:02 AM
 */

#include "Nodo.h"

Nodo::Nodo(Vehiculo* unidad)
    : unidad(unidad), izq(), der() {
    // Se hace una copia del puntero, por indicación.
}

Nodo::~Nodo() {
    // La eliminación del Vehiculo se delega a la clase Flota.
    // if (unidad) delete unidad;
    if (izq) delete izq;
    if (der) delete der;
}

