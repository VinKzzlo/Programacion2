/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Programacion.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 09:05 AM
 */

#ifndef PROGRAMACION_H
#define PROGRAMACION_H
#include <string>
#include <fstream>

#include "Arbol.h"
#include "Flota.h"
using namespace std;

class Programacion {
public:
    void cargavehiculos();
    void cargaprogramacion();
    void reducevehiculos(int cantidad);
    void muestraprogramacion() const;
private:
    void verificarArchivo(const ifstream& arch, const char* nombreArch) const;
    void verificarArchivo(const ofstream& arch, const char* nombreArch) const;
private:
    Arbol ADespachos;
    Flota fVehiculos;
};

#endif /* PROGRAMACION_H */

