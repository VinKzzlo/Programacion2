/* 
 * File:   main.cpp
 * Author: Fabricio Favian Cáceres Lecaros
 * Código: 20214115
 *
 * Created on 5 de diciembre de 2023, 07:59 AM
 */

#include "Programacion.h"
using namespace std;

int main(int argc, char** argv) {
    Programacion pro;
    
    pro.cargavehiculos();
    pro.cargaprogramacion();
    pro.reducevehiculos(10);
    pro.muestraprogramacion();
    
    return 0;
}