/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 08:07 AM
 */

#ifndef FLOTA_H
#define FLOTA_H
#include <string>
#include <fstream>
#include <map>
using namespace std;
#include "Vehiculo.h"
#include "Arbol.h"

class Flota {
public:
    virtual ~Flota();
    
    void cargar_vehiculos();
    void cargar_pedidos();
    void mostrar_vehiculos() const;
    
    void cargarVehiculosEnArbol(Arbol& arbol) const;
private:
    void verificarArchivo(const ifstream& arch, const char* nombreArch) const;
    void verificarArchivo(const ofstream& arch, const char* nombreArch) const;
private:
    map<string, Vehiculo*> vehiculos;
};

#endif /* FLOTA_H */

