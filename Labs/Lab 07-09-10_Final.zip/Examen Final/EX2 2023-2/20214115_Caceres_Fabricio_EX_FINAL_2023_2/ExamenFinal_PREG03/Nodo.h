/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 09:02 AM
 */

#ifndef NODO_H
#define NODO_H
#include <string>
#include <fstream>
using namespace std;
#include "Vehiculo.h"

class Nodo {
public:
    Nodo(Vehiculo* unidad);
    virtual ~Nodo();
    
    friend class Arbol;
private:
    Vehiculo* unidad;
    Nodo* izq;
    Nodo* der;
};

#endif /* NODO_H */

