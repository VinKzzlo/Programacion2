/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.h
 * Author: alulab14
 *
 * Created on 5 de diciembre de 2023, 09:03 AM
 */

#ifndef ARBOL_H
#define ARBOL_H
#include <string>
#include <fstream>
using namespace std;
#include "Nodo.h"

class Arbol {
public:
    Arbol();
    virtual ~Arbol();
    
    void insertar(Vehiculo* vehiculo);
    void reducirVehiculos(int cantidad);
    void mostrar(ofstream& arch) const;
private:
    void insertar(Nodo*& raiz, Vehiculo* vehiculo);
    void eliminarHojas(Nodo*& raiz);
    void mostrar(ofstream& arch, const Nodo* raiz) const;
private:
    Nodo* raiz;
};

#endif /* ARBOL_H */

