/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Programacion.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 09:05 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Programacion.h"

void Programacion::cargavehiculos() {
    fVehiculos.cargar_vehiculos();
    fVehiculos.cargar_pedidos();
}

void Programacion::cargaprogramacion() {
    fVehiculos.cargarVehiculosEnArbol(ADespachos);
}

void Programacion::reducevehiculos(int cantidad) {
    ADespachos.reducirVehiculos(cantidad);
}

void Programacion::muestraprogramacion() const {
    ofstream arch("Reporte.txt", ios::out);
    verificarArchivo(arch, "Reporte.txt");
    arch << setprecision(2) << fixed;
    
    ADespachos.mostrar(arch);
}

void Programacion::verificarArchivo(const ifstream& arch, const char* nombreArch) const {
    if (arch.is_open()) return;

    cout << "Error abriendo " << nombreArch << endl;
    exit(1);
}

void Programacion::verificarArchivo(const ofstream& arch, const char* nombreArch) const {
    if (arch.is_open()) return;

    cout << "Error abriendo " << nombreArch << endl;
    exit(1);
}