/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.cpp
 * Author: alulab14
 * 
 * Created on 5 de diciembre de 2023, 09:03 AM
 */

#include <iostream>
using namespace std;
#include "Arbol.h"

Arbol::Arbol()
     : raiz() {
}

Arbol::~Arbol() {
    /* El destructor de la clase nodo se encarga de borrar
     * recursivamente el resto del árbol. */
    if (raiz) delete raiz;
}

void Arbol::insertar(Vehiculo* vehiculo) {
    // Llamada a función privada sobrecargada.
    insertar(raiz, vehiculo);
}

void Arbol::reducirVehiculos(int cantidad) {
    int cantPorEliminar = cantidad;
    
    for (int i = 0; i != cantPorEliminar; ++i)
    eliminarHojas(raiz);
}

void Arbol::mostrar(ofstream& arch) const {
    // Llamada a función privada sobrecargada.
    mostrar(arch, raiz);
}

void Arbol::insertar(Nodo*& raiz, Vehiculo* vehiculo) {
    if (not raiz)
        raiz = new Nodo(vehiculo);
    else if (vehiculo->GetDni() > raiz->unidad->GetDni())
        insertar(raiz->der, vehiculo);
    else
        insertar(raiz->izq, vehiculo);
}

void Arbol::eliminarHojas(Nodo*& raiz) {
    if (not raiz) return;
    
    if (not raiz->izq and not raiz->der) {
        delete raiz;
        raiz = nullptr;
        return;
    }
    
    if (raiz->izq) eliminarHojas(raiz->izq);
    else eliminarHojas(raiz->der);
}

void Arbol::mostrar(ofstream& arch, const Nodo* raiz) const {
    if (not raiz) return;
    
    mostrar(arch, raiz->izq);
    raiz->unidad->mostrar(arch);
    mostrar(arch, raiz->der);
}
