/* 
 * File:   Flota.cpp
 * Author: ramir
 * 
 * Created on 2 de julio de 2024, 04:51 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Flota.h"
#include "Furgon.h"
#include "Camion.h"
#define MAX_LINEA 60
Flota::Flota() {
}

Flota::Flota(const Flota& orig) {
}

Flota::~Flota() {
}
/*
F,16552775,S7E-946,300,2,3
C,20864087,O5L-856,1000,2,6
*/
void Flota::cargar_vehiculos(){
    ifstream archVeh("Vehiculos.csv",ios::in);
    if(not archVeh.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Vehiculos.csv"<<endl;
        exit(1);
    }
    char tipo;
    Vehiculo *pveh;
    while(1){
        archVeh>>tipo;
        if(archVeh.eof()) break;
        archVeh.get();
        switch(tipo){
            case 'F':
                pveh = new Furgon;
                break;
            case 'C':
                pveh = new Camion;
                break;
        }
        pveh->lee(archVeh);
        vehiculos[pveh->GetPlaca()] = pveh; //El indice es la placa
    }
}
/*
D5W-953,JXD.139,6,120
D5W-953,CRU.009,5,200
*/
void Flota::cargar_pedidos(){
    ifstream archPed("Pedidos4.csv",ios::in);
    if(not archPed.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Pedidos4.csv"<<endl;
        exit(1);
    }
    string placa;
    Pedido ped;
    while(1){
        getline(archPed,placa,',');
        if(archPed.eof()) break;
        ped.leerDatos(archPed);
        vehiculos[placa]->insertar(ped);
    }
}

void Flota::mostrar_vehiculos(){
    ofstream archRep("Reporte.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo Reporte.txt"<<endl;
        exit(1);
    }
    archRep<<fixed<<setprecision(2);
    archRep<<setw(35)<<"REPORTE DE FLOTA"<<endl;
    imprimirLinea(archRep,'=');
    vehiculos.at(string("A1Q-612"))->mostrar(archRep);
    vehiculos.at(string("D9A-711"))->mostrar(archRep);
    vehiculos.at(string("O8J-848"))->mostrar(archRep);
    vehiculos.at(string("Q5S-871"))->mostrar(archRep);
    vehiculos.at(string("Z4L-514"))->mostrar(archRep);
}

void Flota::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}