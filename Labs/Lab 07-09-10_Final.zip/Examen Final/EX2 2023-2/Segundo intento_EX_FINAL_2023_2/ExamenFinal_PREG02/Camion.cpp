/* 
 * File:   Camion.cpp
 * Author: ramir
 * 
 * Created on 2 de julio de 2024, 04:49 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Camion.h"
#define MAX_LINEA 60
Camion::Camion() {
    ejes = 0;
    llantas = 0;
}

Camion::Camion(const Camion& orig) {
}

Camion::~Camion() {
}
//20864087,O5L-856,1000,2,6
void Camion::lee(ifstream &archVeh){
    char c;
    
    Vehiculo::lee(archVeh); //20864087,O5L-856,1000,
    archVeh>>ejes>>c>>llantas;
    archVeh.get();
}

void Camion::insertar(class Pedido &ped){
    
    if(depositos.size()==5) return;
    if(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso() > GetCarga_maxima())
        return;
    
    depositos.push_back(ped);
    
    SetCarga_actual(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso());
}

void Camion::mostrar(ofstream &archRep){
    Vehiculo::mostrar(archRep);
    archRep<<left<<setw(19)<<"#Llantas:"<<llantas<<endl;
    archRep<<left<<setw(19)<<"#Ejes:"<<ejes<<endl;
    archRep<<"Lista de Pedidos:"<<endl;
    if(depositos.empty()){
        archRep<<"No hay pedidos para el cliente"<<endl;
    }else{
        for(int i=0;i<depositos.size();i++)
            depositos[i].mostrar(archRep);
    }
    imprimirLinea(archRep,'=');
}

void Camion::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}