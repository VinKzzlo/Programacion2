/* 
 * File:   Furgon.h
 * Author: ramir
 *
 * Created on 2 de julio de 2024, 04:50 PM
 */

#ifndef FURGON_H
#define FURGON_H

#include <list>

#include "Vehiculo.h"
#include "Pedido.h"

class Furgon:public Vehiculo {
public:
    Furgon();
    Furgon(const Furgon& orig);
    virtual ~Furgon();
    void lee(ifstream &);
    void insertar(class Pedido &);
    void mostrar(ofstream &);
private:
    int filas;
    int puertas;
    list<class Pedido>depositos;
    void imprimirLinea(ofstream &,char);
};

#endif /* FURGON_H */

