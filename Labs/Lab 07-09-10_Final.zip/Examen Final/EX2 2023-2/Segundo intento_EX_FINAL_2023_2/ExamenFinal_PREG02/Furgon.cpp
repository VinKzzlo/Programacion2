/* 
 * File:   Furgon.cpp
 * Author: ramir
 * 
 * Created on 2 de julio de 2024, 04:50 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Furgon.h"
#define MAX_LINEA 60
Furgon::Furgon() {
    filas = 0;
    puertas = 0;
}

Furgon::Furgon(const Furgon& orig) {
}

Furgon::~Furgon() {
}
//16552775,S7E-946,300,2,3
void Furgon::lee(ifstream &archVeh){
    char c;
    
    Vehiculo::lee(archVeh); //16552775,S7E-946,300,
    archVeh>>filas>>c>>puertas;
    archVeh.get();
}

void Furgon::insertar(class Pedido &ped){
    
    if(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso() > GetCarga_maxima())
        return;
    
    list<class Pedido>::iterator it = depositos.begin();
    
    for(it;it!=depositos.end();it++)
        if(it->GetPeso() > ped.GetPeso()) break;
    
    depositos.insert(it,ped);
    
    SetCarga_actual(GetCarga_actual()+ped.GetCantidad()*ped.GetPeso());
}

void Furgon::mostrar(ofstream &archRep){
    Vehiculo::mostrar(archRep);
    archRep<<left<<setw(19)<<"#Puertas:"<<puertas<<endl;
    archRep<<left<<setw(19)<<"#Filas:"<<filas<<endl;
    archRep<<"Lista de Pedidos:"<<endl;
    if(depositos.empty()){
        archRep<<"No hay pedidos para el cliente"<<endl;
    }else{
        for(list<class Pedido>::iterator
                it=depositos.begin();        it!=depositos.end();    it++){
            it->mostrar(archRep);
        }
    }
    imprimirLinea(archRep,'=');
}

void Furgon::imprimirLinea(ofstream &archRep,char c){
    for(int i=0;i<MAX_LINEA;i++)
        archRep<<c;
    archRep<<endl;
}